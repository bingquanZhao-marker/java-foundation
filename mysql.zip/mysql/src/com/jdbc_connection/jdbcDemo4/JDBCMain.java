package com.jdbc_connection.jdbcDemo4;

import com.jdbc_connection.jdbcDemo2.Student;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class JDBCMain {
    private final String USER ="root";
    private final String PASSWORD="19970909";
    private static final String URL="jdbc:mysql://localhost:3306/mydb?characterEncoding=utf8&useSSL=false";
    private final String DRIVER="com.mysql.cj.jdbc.Driver";
    private Connection connection;
    private Statement statement;
    private PreparedStatement preparedStatement;
    private JDBCMain(){
        try {
            Class.forName(DRIVER);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
    public void initConfig()throws SQLException{

        connection=DriverManager.getConnection(URL,USER,PASSWORD);
        statement = connection.createStatement();
    }

    public boolean insertStudent(Student student) throws SQLException {
        boolean flag =false;
        String sql = "insert into student(name,age)values('"+student.getName()+"',"+student.getAge()+")";
       int effect_row= statement.executeUpdate(sql);
        flag = (effect_row>0?true:false);
            return flag;

    }

    public boolean updateStudent(Student student)throws SQLException{
        boolean flag =false;
        String sql ="update student set name='" + student.getName() + "',age = " + student.getAge() + " where id = " + student.getId() + "";
        int effect_row = statement.executeUpdate(sql);
        flag =(effect_row>0?true:false);
        return flag;
    }

    /**
     *
     * @param id
     * @return
     * @throws SQLException
     */
    public boolean deleteStudent(int id)throws SQLException{
        boolean flag =false;
        String sql="delete from student where id="+id+"";
        int effect_row = statement.executeUpdate(sql);
        flag =(effect_row>0?true:false);
        return flag;
    }

    public Student viewStudent(int id)throws SQLException{
       Student student =new Student();
       String sql="select id,name,age from student where id="+id+"";
       ResultSet resultSet = statement.executeQuery(sql);
        while (resultSet.next()) {
            student.setName(resultSet.getString("name"));
            student.setAge(resultSet.getInt("age"));
            student.setId(resultSet.getInt("id"));
        }
        return student;
    }




    public List<Student> viewMultiStudent() throws SQLException {
        List<Student> list = new ArrayList<>();
        String sql = "select name,id,age from student";
        ResultSet resultSet =statement.executeQuery(sql);
        while(resultSet.next()){
            Student student =new Student();
            student.setName(resultSet.getString("name"));
            student.setAge(resultSet.getInt("age"));
            student.setId(resultSet.getInt("id"));
            list.add(student);
        }
        return list;
    }
    public boolean insertStudentByPre(Student student) throws SQLException {
        boolean flag =false;
        String sql ="insert into student(name,age)values(?,?)";
        preparedStatement= connection.prepareStatement(sql);
        preparedStatement.setString(1,student.getName());
        preparedStatement.setInt(2,student.getAge());
        flag=(preparedStatement.executeUpdate()>0?true:false);
        return flag;
    }
    public static void main(String[] args) {

    }
}
