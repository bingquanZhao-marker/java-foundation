package com.jdbc_connection.JdbcDemo3;


import com.jdbc_connection.jdbcDemo2.Student;

import java.sql.*;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class TestDBManager {
    private DBmanager manager;
    public TestDBManager(){
        manager= DBmanager.getInstance();
    }

    /**
     * insert 语句 调用的方法为 manager.executeUpdateBySQL(sql, params)
     * @throws Exception
     */
    public void insertStudent()throws Exception {
        String sql = "insert into student(name,age)values(?,?)";
        List<Object> params = Arrays.asList("rosett", 100);
        manager.getConnection();
        int result = manager.executeUpdateBySQL(sql, params);
        if (result > 0) {
            System.out.println("插入成功");
        }
    }

    /**
     * delete 语句 删除一个记录，调用的方法为 manager.executeUpdateBySQL(sql, params)
     * @throws Exception
     */
    public void deleteStudent() throws Exception{
        String sql = "delete from student where id =?";
        List<Object> params = Arrays.asList(4);
        manager.getConnection();
        int result = manager.executeUpdateBySQL(sql,params);
        if(result>0){
            System.out.println("删除成功");
        }
    }

    /**
     * 返回结果是Map，执行一个简单的查询，格式为sql ="select *from student where id=?";
     * @param sql
     * @param id
     * @return
     * @throws SQLException
     */
    public Map<String,Object> viewStudent(String sql,int id) {
        Map<String,Object> map =null;
       // String sql ="select *from student where id=?";
        List<Object> params = Arrays.asList(id);

        try {
            manager.getConnection();
            map=manager.executeSingleMapBySQL(sql,params);
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            manager.closeAll();
        }


        return map;
    }


    /**
     * 返回结果是一个List<Map<String,Object>> ,可以执行查询多行的记录
     * 格式为  sql=SELECT * FROM emp e,dept d where e.deptno = d.deptno and d.deptno = ?
     * @param sql
     * @param deptno
     * @return
     */
    public List<Map<String,Object>> viewMultiEmp(String sql,int deptno){
        List<Map<String,Object>> list =null;
        try {
            manager.getConnection();
            list = manager.executeMultiMapBySQL(sql,Arrays.asList(deptno));
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            manager.closeAll();
        }
        return list;
    }

    /**
     * 返回一个Student 的对象 执行的方法为manager.executeSingleObjectBySQL(sql,Arrays.asList(id),cls);
     * SQL语句为 "select * from student where id = ?";
     * @param sql
     * @param id
     * @param cls
     * @return
     */
    public Student viewObject(String sql,int id,Class<?> cls){
        Student student = null;
        try {
            manager.getConnection();
            student =manager.executeSingleObjectBySQL(sql,Arrays.asList(id),cls);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
        }finally {
            manager.closeAll();
        }
        return student;
    }

    /**
     * 返回List<Student> 执行方法为manager.executeMutiObjectBySQL(sql,null,cls);
     * @param sql
     * @param cls
     * @return
     */
    public List<Student> viewMultiObject(String sql,Class<?> cls){
        List<Student> list =null;
        try {
            manager.getConnection();
            list = manager.executeMutiObjectBySQL(sql,null,cls);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
        }finally {
            manager.closeAll();
        }
        return list;
    }







//    public void insert()throws Exception {
//        String sql ="inset into teach(name,birthday,info,pic)values(?,?,?,?)";
//        Date birthday = new Date(1980,10,23);
//        manager.getConnection();
//       int row_result= manager.executeUpdateBySQL(sql,"王富贵", birthday,new FileReader(""),new FileInputStream(""));
//       if(row_result>0){
//           System.out.println("插入数据库成功");
//       }
//
//    }
//    public void view()throws Exception{
//String sql = "select info,pic from teach where id=?";
//manager.getConnection();
//        ResultSet resultSet  =manager.queryOne(sql,3);
//        if(resultSet.next()){
//            Clob info=resultSet.getClob("info");
//            Reader reader=info.getCharacterStream();
//            StringBuilder builder =new StringBuilder();
//           char[] chars =new char[10];
//           int len =0;
//           while((len = reader.read(chars))!=-1){
//               builder.append(new String(chars,0,len));
//           }
//            System.out.println(builder.toString());
//            reader.close();
//            Blob blob =resultSet.getBlob("pic");
//        }
//    }

    public static void main(String[] args)throws Exception {
       // new TestDBManager().insert();
       //new TestDBManager().view();

//        new TestDBManager().insertStudent();
//        new TestDBManager().deleteStudent();

        //测试学生表
//        String sql = "select * from student where id = ?";
//        Map<String, Object> map = new TestDBManager().viewStudent(sql, 3);
//
//        System.out.println("---->>" + map.get("name"));
//        System.out.println("---->>" + map.get("age"));

        //测试emp表
//        String sql ="SELECT * FROM emp e,dept d where e.deptno = d.deptno and d.deptno = ? ";
//        List<Map<String,Object>> result = new TestDBManager().viewMultiEmp(sql,20);
//        for (Map<String, Object> map : result) {
//            for(Map.Entry<String,Object> entry: map.entrySet()){
//                System.out.println("-----columnsName-->"+entry.getKey()+"---values--->"+entry.getValue());
//            }
//            System.out.println("---------------------------------------------------------------------------------");
//        }



//
        String sql ="select id,name,age from student";
        List<Student> list =new TestDBManager().viewMultiObject(sql,Student.class);
        System.out.println(list);


    }
}
