package com.jdbc_connection.jdbc;

import com.mchange.v2.c3p0.ComboPooledDataSource;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class RollBack {
    private static  final String USER="root";
    private static final  String PASSWORD="19970909";
    private static final String URL="jdbc:mysql://localhost:3306/mydb?characterEncoding=utf8&useSSL=false";
    private Connection connection;
    private PreparedStatement preparedStatement;

    public RollBack() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        try {
            connection = DriverManager.getConnection(URL,USER,PASSWORD);
            connection.setAutoCommit(false);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void addStudent(){
        String sql = "insert into student(name,age)values(?,?)";
        try {
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1,"www");
            preparedStatement.setInt(2,34);
            int flag =1/0;
            System.out.println(flag);
            int result = preparedStatement.executeUpdate();

            if(result>0){
                System.out.println("插入成功");

            }else{
                System.out.println("error");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            try {
                connection.rollback();
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
        }

    }

    public static void main(String[] args) {
        new RollBack().addStudent();
    }
}
