package com.jdbc_connection.mysql_excel;

import javax.swing.*;

public class Excel {
    public void exportToExcel() {
        JButton toExcelButton  = new JButton("导出Excel");
    }
}