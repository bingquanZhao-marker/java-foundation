package com.jdbc_connection.mysql_excel;

import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.hssf.util.HSSFCellUtil;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellRangeAddress;

import javax.swing.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Excel写操作帮助类
 */

public class ExcelUtil {
    /**
     * 创建HSSFSheet 工作薄
     * @param wb
     * @param sheetName
     * @return HSSFSheet
     */
    public static HSSFSheet createSheet(HSSFWorkbook wb,String sheetName){
        HSSFSheet sheet = wb.createSheet(sheetName);
        sheet.setDefaultColumnWidth(12);
        sheet.setGridsPrinted(false);
        sheet.setDisplayGridlines(false);
        return sheet;
    }

    /**
     * 创建HSSFRow
     * @param sheet
     * @param rowNum
     * @param height
     * @return
     */
    public static HSSFRow createRow(HSSFSheet sheet,int rowNum,int height){
        HSSFRow row = sheet.createRow(rowNum);
        row.setHeight((short)height);
        return row;
    }


    public static HSSFCell createCell(HSSFRow row ,int cellNum){
        HSSFCell cell = row.createCell(cellNum);
        return  cell;
    }

    /**
     * 创建CellStyle
     * @param row
     * @param cellNum
     * @param style
     * @return
     */
    public static HSSFCell createCell(HSSFRow row, int cellNum, CellStyle style){
        HSSFCell cell = row.createCell(cellNum);
        cell.setCellStyle(style);
        return cell;
    }

    /**
     * 创建CellStyle样式
     * @param wb
     * @param backgroundColor   背景色
     * @param halign     前景色
     * @param font    字体
     * @return   CellStyle
     */
    public static CellStyle createCellStyle(HSSFWorkbook wb, short backgroundColor, short halign, Font font){
        CellStyle cs = wb.createCellStyle();
        cs.setAlignment(halign);
        cs.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
        cs.setFillBackgroundColor(backgroundColor);
        cs.setFillForegroundColor(CellStyle.SOLID_FOREGROUND);
        cs.setFillPattern(CellStyle.SOLID_FOREGROUND);
        cs.setFont(font);
        return cs;

    }

    /**
     * 创建带边框的CellStyle样式
     * @param wb             HSSFWorkbook
     * @param backgroundColor   背景色
     * @param foregroundColor   前景色
     * @param halign          字体
     * @param font
     * @return        CellStyle
     */

    public static CellStyle createBorderCellStyle(HSSFWorkbook wb,short backgroundColor,short foregroundColor,short halign,Font font){
        CellStyle cs = wb.createCellStyle();
        cs.setAlignment(halign);
        cs.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
        cs.setFillBackgroundColor(backgroundColor);
        cs.setFillForegroundColor(foregroundColor);
        cs.setFillPattern(CellStyle.SOLID_FOREGROUND);
        cs.setFont(font);
        cs.setBorderLeft(CellStyle.BORDER_DASHED);
        cs.setBorderRight(CellStyle.BORDER_DASHED);
        cs.setBorderTop(CellStyle.BORDER_DASHED);
        cs.setBorderBottom(CellStyle.BORDER_DASHED);

        return cs;
    }

    /**
     * 多行导入到Excel并且设置标题栏格式
     */
    public static void writeArrayToExcel(HSSFSheet sheet,int rows,int cells,Object[][] value){
        Row row[] =new HSSFRow[rows];
        Cell cell[] = new HSSFCell[cells];

        for (int i = 0; i < row.length; i++) {
            row[i]=sheet.createRow(i);

            for(int j =0; j<cell.length ;j++){
                cell[j]=row[i].createCell(j);
                cell[j].setCellValue(convertString(value[i][j]));
            }
        }
    }
    public static String convertString(Object value){
        if(value == null){
            return "";
        }else {
            return value.toString();
        }
    }

    /**
     * 功能：多行多列导入到Excel并且设置标题栏格式
     * @param wb
     * @param sheet
     * @param rows
     * @param cells
     * @param value
     */

    public static void writeArrayToExcel(HSSFWorkbook wb,HSSFSheet sheet,int rows,int cells,Object[][] value){
        Row row[] = new HSSFRow[rows];
        Cell cell[] = new HSSFCell[cells];

        HSSFCellStyle ztStyle = (HSSFCellStyle) wb.createCellStyle();
        Font ztFont = wb.createFont();
        ztFont.setItalic(true);    //设置字体为斜体
        ztFont.setColor(Font.COLOR_RED);   //将字体设置为红色
        ztFont.setFontHeightInPoints((short)10);
        ztFont.setFontName("华文行楷");
        ztStyle.setFont(ztFont);

        for (int i = 0; i <row.length ; i++) {
            row[i]=sheet.createRow(i);

            for (int j = 0; j < cell.length; j++) {
                cell[j]=row[i].createCell(j);
                cell[j].setCellValue(convertString(value[i][j]));

                if (i == 0){
                    cell[j].setCellStyle(ztStyle);
                }
            }
        }
    }

    /**
     * 功能：合并单元格
     * @param sheet
     * @param firstRow
     * @param lastRow
     * @param firstColumn
     * @param lastColumn
     * @return
     */
    public static int mergeCell(HSSFSheet sheet,int firstRow,int lastRow,int firstColumn,int lastColumn){
        return sheet.addMergedRegion(new CellRangeAddress(firstRow,lastRow,firstColumn,lastColumn));
    }
    public static Font createFont(HSSFWorkbook wb,short boldweight,short color,short size){
        Font font = wb.createFont();
        font.setBoldweight(boldweight);
        font.setColor(color);
        font.setFontHeightInPoints(size);
        return  font;
    }

    /**
     * 设置合并单元格的边框样式
     * @param sheet    HSSFSheet
     * @param ca        CellRangeAddress
     * @param style     CellStyle
     */
    public static void setRegionStyle(HSSFSheet sheet,CellRangeAddress ca,CellStyle style){
        for (int i = ca.getFirstRow(); i <ca.getLastRow() ; i++) {
            HSSFRow row = HSSFCellUtil.getRow(i,sheet);
            for (int j = ca.getFirstColumn(); j <ca.getLastRow() ; j++) {
                HSSFCell cell =HSSFCellUtil.getCell(row,j);
                cell.setCellStyle(style);
            }
        }
    }

    public static  void writeWorkbook(HSSFWorkbook wb,String fileName){
        FileOutputStream fos = null;
        File f =new File(fileName);
        try {
            fos = new FileOutputStream(f);
            wb.write(fos);
            int dialog = JOptionPane.showConfirmDialog(null,
                    f.getName()+"导出成功！是否打开？","温馨提示",JOptionPane.YES_NO_OPTION);
            if (dialog == JOptionPane.YES_NO_OPTION){
                Runtime.getRuntime().exec("cmd /c start \"\" \" " +fileName+"\"");
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null,"没有进行筛选");
        } catch (IOException e) {
            e.printStackTrace();
        }finally {

                try {
                    if (fos!=null) {
                        fos.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }

        }
    }

}
