package com.jdbc_connection.jdbcDemo2;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TestStudent {

    private  JDBCManager manager;

    public TestStudent(){
        manager =JDBCManager.getInstance();
    }

    /**
     * 执行删除语句的方法
     */
    public void delete(){
        String sql ="delete from student where id =2";
        try {
            manager.getConnection();
            int row_result = manager.executeSQLByStatement(sql);
            //判断受影响的行数，若不等于0则删除成功
            if(row_result>0){
                System.out.println("删除学生记录成功");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            manager.closeAll();
        }
    }

    /**
     * 执行插入语句
     * @param val 传入的参数是一个Object类型的数组，在调用insert()方法的时候就需要把参数传入
     *            以便以执行SQL语句
     */
    public void insert(Object[] val){
        //需要外传值来补全SQL语句
        String sql = "insert into student(name,age)values('"+val[0]+"',"+val[1]+")";
        try {
            manager.getConnection();
            //这里的String 是上面SQL中的
            int row_count = manager.executeSQLBYStatement(sql,new String[]{"name","age"});
            if(row_count>0){
                System.out.println("添加学生成功");
            }
            System.out.println("--->"+sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Statement 是静态的，为了实现能够将SQL语句写成可变的，传入Object[] 数组 次数在中写入 fielsName 对应的 value
     * @param val
     */
    public void update(Object[] val){
        String sql = "update student set name = '"+val[0]+"' ,age="+val[1]+" where id="+val[2]+" ";
        System.out.println("--->"+sql);
        try {
            manager.getConnection();
            int row_count = manager.executeSQLBYStatement(sql,new String[]{"name","age","id"});
            if(row_count>0){
                System.out.println("修改学生成功");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * 查询语句
     */
    public void  querySingleResult(){
        String sql ="select name,age from student where id=5";
        System.out.println("--->"+sql);
        try {
            manager.getConnection();
            //返回查询的结果集
            ResultSet resultSet =manager.executeQuetyBYStatement(sql);
            while (resultSet.next()){
                System.out.println("-->"+resultSet.getString("name"));
                System.out.println("-->"+resultSet.getInt("age"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }
    /**
     *  查询单个结果
     *  创建一个响应的类来接受查询到的返回值，并且输出这个类的引用
     */

    public Student queryOneResult(){
        Student stu = new Student();
        String sql ="select name,age from where id=5";
        System.out.println("--->"+sql);
        ResultSet resultSet=null;
        try {
            manager.getConnection();
            resultSet = manager.executeQuetyBYStatement(sql);
            if(resultSet.next()){
                stu.setName(resultSet.getString("naame"));
                stu.setAge(resultSet.getInt("age"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            manager.closeAll();
        }
       return stu;
    }

    /**
     * 查询多个结果
     * @return List<Student> list
     */

    public List<Student> queryMoreResult(){
        String sql = "select id, name ,age from student";
        List<Student> list = new ArrayList<>();
        ResultSet resultset =null;
        try {
            manager.getConnection();
            resultset =manager.executeQuetyBYStatement(sql);
            while(resultset.next()){
                Student student =new Student();
                student.setAge(resultset.getInt("age"));
                student.setId(resultset.getInt("id"));
                student.setName(resultset.getString("name"));
                list.add(student);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            manager.closeAll();
        }
   return list;
    }
    public static void main(String[] args) {
        //new TestStudent().insert(new Object[]{"zhangsan", 45});
        // new TestStudent().update(new Object[]{"lisi", 66, 5});
        //new TestStudent().querySingleResult();
        // Student student = new TestStudent().queryOneResult();
        // System.out.println(student);
        System.out.println(new TestStudent().queryMoreResult());

    }
}
