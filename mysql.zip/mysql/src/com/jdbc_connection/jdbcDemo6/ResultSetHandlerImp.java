package com.jdbc_connection.jdbcDemo6;

import org.apache.commons.dbutils.ResultSetHandler;

import java.sql.ResultSet;
import java.sql.SQLException;

public class ResultSetHandlerImp implements ResultSetHandler {



    @Override
    public Object handle(ResultSet resultSet) throws SQLException {
        return null;
    }
}
