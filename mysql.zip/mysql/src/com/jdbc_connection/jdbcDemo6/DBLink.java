package com.jdbc_connection.jdbcDemo6;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class DBLink {
    private static Connection connection;
    private static ResourceBundle bundle =ResourceBundle.getBundle("com.jdbc_connection/jdbcDemo6/db-config");

    //Properties 加载属性文件

    static {
        try {
            Class.forName(bundle.getString("jdbc.driver"));
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        try {
            connection = DriverManager.getConnection(bundle.getString("jdbc.url"),
                    bundle.getString("jdbc.user"),bundle.getString("jdbc.password"));
            System.out.println("连接成功");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static  Connection getConnection(){
        return connection;
    }
    public static void main(String[] args) {
        getConnection();
    }
}

