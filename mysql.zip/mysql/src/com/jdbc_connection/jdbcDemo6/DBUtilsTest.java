package com.jdbc_connection.jdbcDemo6;

import com.jdbc_connection.jdbcDemo2.Student;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.ResultSetHandler;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.MapHandler;
import org.apache.commons.dbutils.handlers.MapListHandler;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 使用DbUtil 工具包来实现jdbc对数据库的操作
 */

public class DBUtilsTest {

    /**
     * sql为插入语句，使用的方法为
     * 返回值              方法参数结构
     * int        update(Connection conn, String sql, Object param)
     */
    public static void demo1(){
        QueryRunner queryRunner = new QueryRunner();
        String sql = "insert into student(name,age)values(?,?)";
        try {
            int result=queryRunner.update(DBLink.getConnection(),sql,new Object[]{"jack",21});
            System.out.println(result);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    /**
     *sql为修改语句，使用的方法为
     * 返回值              方法参数结构
     * int        update(Connection conn, String sql, Object param)
     */

    public static void demo2(){
        QueryRunner queryRunner  =new QueryRunner();
        String sql= "update student set name= ? ,age= ? where id= ? ";
        try {
            int result = queryRunner.update(DBLink.getConnection(),sql,new Object[]{"jquery",31,1});
            System.out.println(result);
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }
    /**
     *sql为删除语句，使用的方法为
     * 返回值              方法参数结构
     * int        update(Connection conn, String sql, Object param)
     */
    public static void demo3(){
        QueryRunner queryRunner =new QueryRunner();
        String sql ="delete from student where id = ?";
        try {
            int result = queryRunner.update(DBLink.getConnection(),sql,new Object[]{1});
            System.out.println(result);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    /**
     *sql为查询单行结果的语句，使用的方法为
     * 返回值              方法参数结构
     * <T> T        query(Connection conn, String sql, ResultSetHandler<T> rsh)
     * ResultSetHandler<T>为一个接口，需要自己实现并且实现handle 方法 handle方法可以返回T类型的结果
     *
     */
    public static  void demo4(){
        QueryRunner queryRunner =new QueryRunner();
        String sql ="select * from student where id =1";
        List<Student> list =null;
        try {
            list =queryRunner.query(DBLink.getConnection(), sql, new ResultSetHandler<List<Student>>() {
                @Override
                public List<Student> handle(ResultSet resultSet) throws SQLException {
                    List<Student> list =new ArrayList<>();
                    while(resultSet.next()) {
                        Student student = new Student();
                        student.setName(resultSet.getString("name"));
                        student.setAge((resultSet.getInt("age")));
                        student.setId(resultSet.getInt("id"));
                        list.add(student);
                    }
                    return list;
                }
            });
        } catch (SQLException e) {
            e.printStackTrace();
        }
        System.out.println(list);

    }
    /**
     *sql为查询单行结果的语句，使用的方法为
     * 返回值              方法参数结构
     * <T> T        query(Connection conn, String sql, ResultSetHandler<T> rsh, Object... params)
     * ResultSetHandler<T>为一个接口，需要自己实现并且实现handle 方法 handle方法可以返回T类型的结果
     *
     */
    public static void demo5(){
        QueryRunner queryRunner = new QueryRunner();
        String sql = "select * from student where id = ? ";
        Student stu =null;
        try {
           stu= queryRunner.query(DBLink.getConnection(),sql, new ResultSetHandler<Student>() {
                @Override
                public Student handle(ResultSet resultSet) throws SQLException {
                    Student student = new Student();
                    if(resultSet.next()){
                        student.setName(resultSet.getString("name"));
                        student.setAge((resultSet.getInt("age")));
                        student.setId(resultSet.getInt("id"));
                    }
                    return student;
                }
            },new Object[]{1});
        } catch (SQLException e) {
            e.printStackTrace();
        }
        System.out.println(stu);
    }

    /**
     * 将查询结果转换成一个javaBean对象
     * 返回值              方法参数结构
     * <T> T        query(Connection conn, String sql, ResultSetHandler<T> rsh, Object... params)
     * BeanHandler类是ResultSetHandler<T>接口的实现类，其构造方法为BeanHandler(Class<? extends T> type)
     */
    public static void demo6(){

        QueryRunner queryRunner = new QueryRunner();
        String sql = "select * from student where id = ? ";
        Student stu = null;
        try {
            stu =  queryRunner.query(DBLink.getConnection(),sql,new BeanHandler<>(Student.class),new Object[]{5});
        } catch (SQLException e) {
            e.printStackTrace();
        }

        System.out.println(stu);
    }
    /**
     * 将查询结果转换成一个javaBean对象
     * 返回值              方法参数结构
     * <T> T        query(Connection conn, String sql, ResultSetHandler<T> rsh, Object... params)
     * BeanHandler类是ResultSetHandler<T>接口的实现类，其构造方法为BeanHandler(Class<? extends T> type)
     */
    public static void demo7(){
        QueryRunner queryRunner = new QueryRunner();
        String sql = "select * from student where age > ?";
        try {
            List<Student> list =  queryRunner.query(DBLink.getConnection(),sql,new BeanListHandler<>(Student.class),new Object[]{50});
            System.out.println(list);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    /**
     *sql为查询单行结果的语句，使用的方法为
     * 返回值              方法参数结构
     * <T> T        query(Connection conn, String sql, ResultSetHandler<T> rsh, Object... params)
     * ResultSetHandler<T>为一个接口,使用它的实现类MapHandle()，MapHandle()实现了handle方法
     */
    public static void demo8(){
        QueryRunner queryRunner =new QueryRunner();
        String sql ="select * from student where id= ?";

        try {
            Map<String,Object> map = queryRunner.query(DBLink.getConnection(),sql,new MapHandler(),new Object[]{1});
            System.out.println(map);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     *sql为查询单行结果的语句，使用的方法为
     * 返回值              方法参数结构
     * <T> T        query(Connection conn, String sql, ResultSetHandler<T> rsh, Object... params)
     * ResultSetHandler<T>为一个接口,使用它的实现类MapHandle()，MapListHandle()实现了handle方法
     */
    public static void demo10(){
        QueryRunner queryRunner = new QueryRunner();
        String sql ="select * from student where age >?";
        try {
            List<Map<String,Object>> list = queryRunner.query(DBLink.getConnection(),sql,new MapListHandler(),new Object[]{30});
            System.out.println(list);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     *
     * @param sql sql语句  如select * from student where id=?
     * @param cls 类的类型
     * @param args 以占位符来决定传参的Object[]{};
     * @param <T>  返回值为传入BeanHandler(Class<? extends T> type)的泛型
     * @return
     */
    public static <T> T demo10(String sql,Class cls ,Object[] args){
        QueryRunner queryRunner = new QueryRunner();
        T t=null;
        try {
           t=(T)queryRunner.query(DBLink.getConnection(),sql,new BeanHandler<>(Student.class),new Object[]{1},args);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return t;
    }




    public static void main(String[] args) {

//Student student =demo10("select * from studet where id =",Student.class,new Object[]{5});
//        System.out.println(student);
    }
}
