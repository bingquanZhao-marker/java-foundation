package com.jdbc_connection.exam;



import java.sql.*;
import java.util.List;

public class DBConnectUtils {
    private final String USER ="root";
    private final String PASSWORD="19970909";
    private static final String URL="jdbc:mysql://localhost:3306/mydb?characterEncoding=utf8&useSSL=false";
    private final String DRIVER="com.mysql.cj.jdbc.Driver";
    private static DBConnectUtils instance;
    private PreparedStatement preparedStatement;

    private Connection connection;
    private DBConnectUtils(){

        try {
            Class.forName(DRIVER);
            System.out.println("注册MySQL驱动成功");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

    }
    public static  DBConnectUtils getInstance(){
        if(instance == null){
            instance = new DBConnectUtils();
        }
        return instance;
    }
    public Connection getConnection(){
        try {
            connection= DriverManager.getConnection(URL,USER,PASSWORD);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return connection;
    }
    public int executeUpdateSQL(String sql, List<Object> params)throws SQLException{
        preparedStatement = connection.prepareStatement(sql);
        int index = 1;
        if(params!=null&&!params.isEmpty()){
            for (int i = 0; i <params.size() ; i++) {
                preparedStatement.setObject(index++,params.get(i));
            }
        }
        int effect_row = preparedStatement.executeUpdate();
        return effect_row;
    }
    public void closeALl(){
        try {
            if(preparedStatement!=null) {
                preparedStatement.close();
            }
            if(connection!=null){
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
