package com.jdbc_connection.exam;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class GetProperFile {
    private FileInputStream fileInputStream;
    private final String url="/Users/apple/Desktop/product.properties";
    public  List<Object> demo(){
        List<Object> list = new ArrayList<>();
        try {
            fileInputStream =new FileInputStream(url);
            Properties properties =new Properties();
            properties.load(fileInputStream);
            //String no=properties.getProperty("pro_no");
            String name=properties.getProperty("pro_name");
            String  date =  properties.getProperty("pro_date");
            String place =properties.getProperty("pro_place");
            String price=properties.getProperty("pro_price");
            //list.add(no);
            list.add(name);
            list.add(date);
            list.add(place);
            list.add(price);

            System.out.println(list);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return list;
    }

    public static void main(String[] args) {
        GetProperFile getProperFile =new GetProperFile();
        getProperFile.demo();
    }

}
