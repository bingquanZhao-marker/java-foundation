package com.jdbc_connection.exam;


import java.sql.SQLException;
import java.util.List;

public class TestDBConnectUtils {
    private DBConnectUtils dbConnectUtils;

    public TestDBConnectUtils(){
       dbConnectUtils= DBConnectUtils.getInstance();
    }
    public  void insertProduct(){
        dbConnectUtils.getConnection();
        String sql ="insert into product(pro_name,pro_date,pro_place,pro_price)values(?,?,?,?)";
        GetProperFile getProperFile =new GetProperFile();
        List<Object> list= getProperFile.demo();
        try {
            int result = dbConnectUtils.executeUpdateSQL(sql,list);
            if (result > 0) {
                System.out.println("插入成功");
            }
            dbConnectUtils.closeALl();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public static void main(String[] args) {
        TestDBConnectUtils t = new TestDBConnectUtils();
        t.insertProduct();
    }
}
