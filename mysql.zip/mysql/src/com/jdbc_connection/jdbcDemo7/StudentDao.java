package com.jdbc_connection.jdbcDemo7;

import java.util.List;
import java.util.Map;

public interface StudentDao {
    boolean addStudent(Student student);
    boolean updateStudent(Student student);
    boolean deleteStudent(int id);
    Student viewStudentByID(int id);
    Map<String,Object> viewMapByID(int id);
    List<Student> queryMultiStudent(String name);
    List<Map<String,Object>> queryMultiMapForStudent(int age);
}
