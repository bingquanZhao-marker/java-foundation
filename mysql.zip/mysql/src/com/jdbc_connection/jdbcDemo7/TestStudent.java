package com.jdbc_connection.jdbcDemo7;


import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;

import java.sql.SQLException;

public class TestStudent {
    public static  void demo1(){
        QueryRunner queryRunner = new QueryRunner();
        String sql="select * from student where id = ?";
        try {
            Student student =queryRunner.query(DBPoolUtils.getConnection(),sql,new BeanHandler<>(Student.class));
            System.out.println(student);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        demo1();
    }
}
