package com.jdbc_connection.jdbcDemo7;

import org.apache.commons.dbutils.DbUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.MapHandler;
import org.apache.commons.dbutils.handlers.MapListHandler;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public class StudentDaoImp implements StudentDao {
    public StudentDaoImp() {
    }

    @Override
    public boolean addStudent(Student student) {
        QueryRunner queryRunner = new QueryRunner();
        Connection connection =null;
        String sql ="insert into student(name,age)values(?,?)";
        boolean flag =false;
        try {
            connection = DBPoolUtils.getConnection();
            int result=queryRunner.update(connection,sql,new Object[]{student.getName(),student.getAge()});
            flag =result>0?true:false;
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {

        }
        return flag;
    }

    @Override
    public boolean updateStudent(Student student) {
        QueryRunner queryRunner = new QueryRunner();
        Connection connection =null;
        String sql ="insert into student(name,age)values(?,?)";
        boolean flag =false;
        try {
            connection = DBPoolUtils.getConnection();
            int result=queryRunner.update(connection,sql,new Object[]{student.getName(),student.getAge()});
            flag =result>0?true:false;
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {

        }
        return false;
    }

    @Override
    public boolean deleteStudent(int id) {
        QueryRunner queryRunner = new QueryRunner();
        Connection connection =null;
        String sql ="delete ";
        boolean flag =false;
        try {
            connection = DBPoolUtils.getConnection();
            int result=queryRunner.update(connection,sql,new Object[]{id});
            flag =result>0?true:false;
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {

        }
        return false;
    }

    @Override
    public Student viewStudentByID(int id) {
        QueryRunner queryRunner = new QueryRunner();
        Connection connection =null;
        String sql="select * from student where id=?";
        try {
            connection=DBPoolUtils.getConnection();
           return queryRunner.query(connection,sql,new BeanHandler<>(Student.class),new Object[]{id});
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            try {
                DbUtils.close(connection);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    @Override
    public Map<String, Object> viewMapByID(int id) {
        QueryRunner queryRunner = new QueryRunner();
        Connection connection =null;
        String sql="select * from student where name like ?";
        try {
            connection=DBPoolUtils.getConnection();
            return queryRunner.query(connection,sql,new MapHandler(),new Object[]{id});
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            try {
                DbUtils.close(connection);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    @Override
    public List<Student> queryMultiStudent(String name) {
        QueryRunner queryRunner = new QueryRunner();
        Connection connection =null;
        String sql="select * from student where name =? ";
        try {
            connection=DBPoolUtils.getConnection();
            return queryRunner.query(connection,sql,new BeanListHandler<>(Student.class),new Object[]{"name"});
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            try {
                DbUtils.close(connection);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    @Override
    public List<Map<String, Object>> queryMultiMapForStudent(int age) {
       QueryRunner queryRunner = new QueryRunner();
       String sql = "select * from student where age>?";
       Connection connection=null;
        try {
            connection=DBPoolUtils.getConnection();
            queryRunner.query(connection,sql,new MapListHandler(),new Object[]{age});
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            try {
                DbUtils.close(connection);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return null;

    }
    public static void main(String[] args) {
        StudentDao dao = new StudentDaoImp();
        Student student = dao.viewStudentByID(5);
        System.out.println(student);
    }

}
