package com.jdbc_connection.jdbcDemo7;

import com.mchange.v2.c3p0.ComboPooledDataSource;


import java.beans.PropertyVetoException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class DBPoolUtils {
    private static ResourceBundle bundle =ResourceBundle.getBundle("com.jdbc_connection/jdbcDemo6/c3p0-config");
    //数据库的连接池
    private static ComboPooledDataSource dataSource = new ComboPooledDataSource();
    static {
        try {
            dataSource.setDriverClass(bundle.getString("jdbc.Driver"));
            dataSource.setJdbcUrl(bundle.getString("jdbc.url"));

            dataSource.setUser(bundle.getString("jdbc.user"));
            dataSource.setPassword(bundle.getString("jdbc.password"));
            dataSource.setAcquireIncrement(Integer.parseInt(bundle.getString("c3p0.acquireIncrement")));
            dataSource.setInitialPoolSize(Integer.parseInt(bundle.getString("c3p0.initialPoolSize")));
            dataSource.setMaxIdleTime(Integer.parseInt(bundle.getString("c3p0.maxIdleTime")));
            dataSource.setMaxPoolSize(Integer.parseInt(bundle.getString("c3p0.maxPoolSize")));
            dataSource.setMinPoolSize(Integer.parseInt(bundle.getString("c3p0.minPoolSize")));

        } catch (PropertyVetoException e) {
            e.printStackTrace();
        }


    }
    public static Connection getConnection()throws SQLException {
        return dataSource.getConnection();
    }
}
