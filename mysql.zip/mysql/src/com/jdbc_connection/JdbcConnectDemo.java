package com.jdbc_connection;

import java.sql.*;

public class JdbcConnectDemo {
    private static Connection connection;

    public static void connectJDBC() {

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        System.out.println("加载驱动成功");
        String url = "jdbc:mysql://localhost:3306/mydb?characterEncoding=utf8&useSSL=false";
        try {
            connection = DriverManager.getConnection(url, "root", "19970909");
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("获取数据库失败");
        }
    }

    public static void getResult() {
        try {
            Statement statement = connection.createStatement();
            String sql = "select * from dept";
            ResultSet resultSet = statement.executeQuery(sql);
            while (resultSet.next()) {
                int deptno = resultSet.getInt("deptno");
                String dname = resultSet.getString("dname");
                String loc = resultSet.getString("loc");

                //输入数据
                System.out.println("deptno=" + deptno);
                System.out.println("dname=" + dname);
                System.out.println("loc=" + loc);
                System.out.println("-------------------------");

            }
            resultSet.close();
             connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        JdbcConnectDemo.connectJDBC();
        JdbcConnectDemo.getResult();

    }
}
