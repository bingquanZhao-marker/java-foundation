package com.jdbc_connection.jdbcDemo5;

import java.util.List;

public class TestDept {
    public void add(){
        DeptDao deptDao = new DeptDaoImp();
        Dept dept =new Dept();
        dept.setDeptno(50);
        dept.setDname("programmer");
        dept.setLoc("beijing");
        deptDao.addDept(dept);

    }
    public void update(){
        DeptDao deptDao = new DeptDaoImp();
        Dept dept =new Dept();
        dept.setDeptno(50);
        dept.setDname("soft");
        dept.setLoc("tianjing");
        deptDao.addDept(dept);
    }
    public void delete(){
        DeptDao deptDao = new DeptDaoImp();
       deptDao.deleteDept(50);
    }
    public void viewOne(){
        DeptDao deptDao = new DeptDaoImp();
      Dept dept = deptDao.viewDept(40);
        System.out.println(dept);
    }
    public void viewMore(){
        DeptDao deptDao = new DeptDaoImp();
        List<Dept> list = deptDao.listDept();
        System.out.println(list);
    }

    public static void main(String[] args) {
        TestDept testDept =new TestDept();
        testDept.add();
    }
}
