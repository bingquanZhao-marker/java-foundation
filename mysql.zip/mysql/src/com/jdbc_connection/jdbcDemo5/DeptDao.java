package com.jdbc_connection.jdbcDemo5;

import java.util.List;

/**
 * 对员工表的操作
 */
public interface DeptDao {
    /**
     * 添加部门信息
     * @param dept
     * @return
     */
    public boolean addDept(Dept dept);

    /**
     * 修该部门信息
     * @param dept
     * @return
     */
    public boolean updateDept(Dept dept);

    /**
     * 删除部门信息
     * @param deptno
     * @return
     */
    public boolean deleteDept(int deptno);

    /**
     * 查看单个部门的信息
     * @param Deptno
     * @return
     */
    public Dept viewDept(int Deptno);

    /**
     * 查看所有部门的信息
     * @return
     */
    public List<Dept> listDept();


}
