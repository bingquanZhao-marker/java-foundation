package com.jdbc_connection.jdbcDemo5;

import com.jdbc_connection.JdbcDemo3.DBmanager;

import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

/**
 * 实现接口
 */
public class DeptDaoImp implements DeptDao {
    private DBmanager dbmanager;

    public DeptDaoImp(){
        dbmanager =DBmanager.getInstance();
    }

    @Override
    public boolean addDept(Dept dept) {
        String sql = "insert into dept(deptno,dname,loc)values(?,?,?)";
        boolean flag =false;
        try {
            dbmanager.getConnection();
            int row_effect=dbmanager.executeUpdateBySQL(sql, Arrays.asList(dept.getDeptno(),dept.getDname(),dept.getLoc()));
            flag =row_effect>0?true:false;
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            dbmanager.closeAll();
        }
        return flag;
    }

    @Override
    public boolean updateDept(Dept dept) {
        String sql="uodate dept set name =?,loc=? where dept = ?";
        boolean flag =false;
        try {
            dbmanager.getConnection();
            int row_effect=dbmanager.executeUpdateBySQL(sql,Arrays.asList(dept.getDname(),dept.getLoc(),dept.getDeptno()));
            flag =row_effect>0?true:false;
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            dbmanager.closeAll();
        }
        return flag;
    }

    @Override
    public boolean deleteDept(int deptno) {
        String sql ="delete from dept where dept =?";
        boolean flag =false;
        try {
            dbmanager.getConnection();
            int row_effect=dbmanager.executeUpdateBySQL(sql,Arrays.asList(deptno));
            flag =row_effect>0?true:false;
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            dbmanager.closeAll();
        }
        return flag;
    }

    @Override
    public Dept viewDept(int deptno) {
        String sql = "select dname,loc from dept where deptno=?";
        Dept dept =null;
        try {
            dbmanager.getConnection();

            dept=dbmanager.executeSingleObjectBySQL(sql,Arrays.asList(deptno),Dept.class);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
        }finally {
            dbmanager.closeAll();
        }
        return dept;
    }

    @Override
    public List<Dept> listDept() {
        String sql = "select deptno,dname,loc from dept";
        List<Dept> list =null;
        try {
            dbmanager.getConnection();
           list = dbmanager.executeMutiObjectBySQL(sql,null,Dept.class);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
        }finally {
            dbmanager.closeAll();
        }

        return null;
    }
}
