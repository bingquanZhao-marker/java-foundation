package com.jdbc_connection;

import com.mysql.cj.jdbc.Driver;

import java .sql.*;

public class FirstExample {
    //jdbc driver name and database URL

    static final String DB_URL="jdbc:mysql://localhost:3306/mydb?userSSL=true&useUnicode=true&characterEncoding=UTF8&serverTimezone=GMT";


    //数据库的用户名与密码，需要根据自己的设置
    static final String USER = "root";
    static final String PASS = "19970909";

    public static void main(String[] args) {
        Connection connection =null;
        Statement statement = null;

        try {
            //注册jdbc 驱动
           // DriverManager.registerDriver(new Driver());
            Class.forName("com.mysql.cj.jdbc.Driver");
            //创建数据库的连接
            connection =DriverManager.getConnection(DB_URL,USER,PASS);

            //创建执行sql语句的对象
            statement = connection.createStatement();


            /*//执行查询
            System.out.println("实例化statement对象. ..");

            String sql= "select * from dept";

            ResultSet resultSet =statement.executeQuery(sql);


            //展开结果集数据库
            while(resultSet.next()){
                int deptno = resultSet.getInt("deptno");
                String dname = resultSet.getString("dname");
                String loc = resultSet.getString("loc");

                //输入数据
                System.out.println("deptno"+deptno);
                System.out.println("dname"+dname);
                System.out.println("loc"+loc);

            }
            //完成后关闭
            resultSet.close();*/
            statement.close();
            connection.close();



        } catch (SQLException e) {
            //处理 Class.forName 错误
            e.printStackTrace();

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } finally {

            try {
                if(connection!=null) {
                    connection.close();
                }
                if(connection!=null) {
                    statement.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }

        }
        System.out.println("goodbye");
    }
}
