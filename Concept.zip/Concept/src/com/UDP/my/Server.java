package com.UDP.my;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

/**
 * UDP server端口
 */

public class Server {
    //定义常量
    private final int MAX_LENGTH =1024;//最大接收字节长度
    private  final int PORT_NUM=5066;//port 号
    //以存放接受数据的字节数组
    private  byte[] receiveMsg = new byte[MAX_LENGTH];
    //数据报套接字
    private DatagramSocket datagramSocket;
    //用于接受数据的数据报
    private DatagramPacket datagramPacket;

    public Server(){
        try {
            //接收数据流程
            //创建一个数据报套接字 ，并将其绑定在指定port上
            datagramSocket = new DatagramSocket(PORT_NUM);
            //DatagramPacket(byte buf[], int length);建立一个字节数组来接受UDP包
            datagramPacket = new DatagramPacket(receiveMsg,datagramPacket.getLength());
            //receive() 来等待UDP数据报
            datagramSocket.receive(datagramPacket);
            /**
             * 解析数据报
             */
            String receiveStr = new String(datagramPacket.getData(),0,datagramPacket.getLength());
            System.out.println("服务器接受"+receiveStr);
            System.out.println("服务器端口"+datagramSocket.getPort());

            /**
             * 返回AKA消息数据报
             */
            //组装数据报
            byte[] data = "I receive message.".getBytes();
            DatagramPacket sendPacket = new DatagramPacket(data,data.length,datagramPacket.getAddress(),datagramPacket.getPort());
            //发送消息
            datagramSocket.send(sendPacket);
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            if(datagramSocket!=null) {
                datagramSocket.close();
            }
        }

    }

    public static void main(String[] args) {
        new Server();
    }

}
