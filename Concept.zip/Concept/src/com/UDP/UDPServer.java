package com.UDP;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.*;

/**
 * 使用UDP发送数据包
 */
public class UDPServer {

    private final  int SOCKET_PORT=6666;
    private DatagramSocket serverSocket;
    private InetAddress address;
    public UDPServer() {
        try {
            address =InetAddress.getLocalHost();
            serverSocket = new DatagramSocket(SOCKET_PORT,address);

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (UnknownHostException e) {
            e.printStackTrace();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void sendMessage() {
        byte[] msg = new byte[1024];

        try {
            //接受客户端发送的消息
           byte[] data = new byte[1024*10];
            //数据包
            DatagramPacket datagramPacket = new DatagramPacket(data,0,data.length,address, SOCKET_PORT);
            serverSocket.receive(datagramPacket);
            byte[] result = datagramPacket.getData();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        //数据包


    }

    public static void main(String[] args) {
        new UDPServer();
    }
}
