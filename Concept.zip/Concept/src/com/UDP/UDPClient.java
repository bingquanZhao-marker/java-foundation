package com.UDP;

import java.io.IOException;
import java.net.*;

public class UDPClient {
    private final  int SOCKET_PORT=6666;
    private DatagramSocket serverSocket;
    private InetAddress address;

    public UDPClient() {
        try {
            address = InetAddress.getLocalHost();
            serverSocket = new DatagramSocket(SOCKET_PORT,address);

        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public  void receive(){

        try {
            byte[] receive_data = new byte[1024];
            DatagramPacket  receive_packet=new DatagramPacket(receive_data,receive_data.length);
            serverSocket.receive(receive_packet);

            byte[] result=receive_packet.getData();
            System.out.println("接受到的数据包信息"+new String(result));
            byte[] send_msg = "haha".getBytes();
            DatagramPacket sed_packet = new DatagramPacket(send_msg,0,send_msg.length);
        } catch (IOException e) {
            e.printStackTrace();
        }



    }

    public static void main(String[] args) {
        new UDPClient().receive();
    }

}
