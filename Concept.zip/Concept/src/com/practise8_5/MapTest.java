package com.practise8_5;


import java.util.*;



public class MapTest {
    public static void main(String[] args) {
        Map<String,String > map= new HashMap<String,String>();
        map.put("1","value");
        map.put("2","value2");
        map.put("3","value3");
        //第一种使用：普遍使用，二次取值
        System.out.println("通过Map.KeySet遍历key和value:");
        for(String key:map.keySet()){
            System.out.println("key="+key+"and value="+map.get(key));
        }
        //第二种
        System.out.println("通过Map.entrySet使用iterator遍历key和把value:");
        Iterator<Map.Entry<String,String>> it = map.entrySet().iterator();
        while (it.hasNext()) {
            System.out.println("通过Map.enTrySet遍历key和value");
        }
        //第三种:推荐，尤其是容量大时
            System.out.println("通过Map.entrySet遍历key和value");
            for(Map.Entry<String,String> entry:map.entrySet()){
                System.out.println("key = [" + entry.getKey() + "and value"+entry.getValue());
            }
            //第四种
            System.out.println("通过Map.values()遍历所有的value，当=但不能遍历key");
            for(String v:map.values()){
                System.out.println("value="+v);
            }

    }
}
