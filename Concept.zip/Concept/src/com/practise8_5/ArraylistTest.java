package com.practise8_5;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
/*迭代器，使你能够通过循环来得到或删除集合的元素。ListIterator继承了Iterator，以允许双向遍历列表和修改元素*/

public class ArraylistTest {
    public static void main(String[] args) {
        List<String> list = new ArrayList<String>();
        list.add("Hello");
        list.add("World");
        list.add("HAHAHAHA");
        //第一种数组遍历的方法 使用foreach遍历List
        for(String string:list){
            System.out.println(string);
        }
        //第二种遍历，把链表变为数组相关的内容进行遍历
        String[] strArray = new String[(list.size())];
        list.toArray();
        for(int i=0;i<strArray.length;i++){
            System.out.println(strArray[i]);
        }
        //第三种遍历  使用迭代器进行相关遍历
        //该方法可以不用担心在遍历的过程中会超过集合的长度

        Iterator<String> ite =list.iterator();
        while(ite.hasNext()){//判断下一个元素之后有值
            System.out.println(ite.next());
        }
    }
}
