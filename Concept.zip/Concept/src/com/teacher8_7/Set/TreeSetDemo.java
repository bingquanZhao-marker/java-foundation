package com.teacher8_7.Set;

import com.teacher8_7.list.Person;

import java.util.Set;
import java.util.TreeSet;

public class TreeSetDemo {
    public static void main(String[] args) {
        Set<Person> all = new TreeSet<>();
        all.add(new Person("B",20));
        all.add(new Person("C",32));
        all.add(new Person("A",33));
        all.add(new Person("A",33));
        all.add(new Person("隔壁老王",88));
        for (Person per:all) {
            System.out.println(per);
        }
    }
}
//通过观察以上代码，可以发现输出有序不重复
//TreeSet的排序呢是通过Compareable接口中的compareTo方法返回的
