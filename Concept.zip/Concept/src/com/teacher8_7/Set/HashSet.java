package com.teacher8_7.Set;

import com.teacher8_7.list.Person;

import java.util.Set;

public class HashSet {
    public static void main(String[] args) {
        Set<Person> all =new java.util.HashSet<>();
//        all.add("hello");
//        all.add("world");
//        all.add("hadoop");
//        all.add("hive");
//        all.add("hbase");
        all.add(new Person("张三",20));
        for (Person per:all) {
            System.out.println(per);

        }
    }
}
/*使用HashSet判断重复元素依据是hashcode和equal()方法
hashCode?
哈希表：字典表 K v hashcode 意思通过一些运算把复杂的对象，主键，转化为数组的
下标arrayindex进行存储

HashCode的设计原理主要三大特性


*/
