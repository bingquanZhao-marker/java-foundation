package com.teacher8_7.Node;

public class LinkList implements List{
    Node head;  //头指针
    Node current;//当前节点
    int size;//记录节点元素的个数

    //初始化一个空链表
    public LinkList(){
        //初始化空的头节点
        this.head=current=new Node(null);
        this.size=0;
    }

    //定位方法，实现当前对象的前一个节点
    public void index(int index)throws Exception{
        //要对输入的index进行判断的
        if(index< -1 ||index>size-1){
            throw new Exception("参数错误");
        }if (index==-1){//如果传进来的节点是头节点直接return
            return;
        }
        current=head.next;
        int j=0;//循环变量
        while (current!=null && j<index){
            current=current.next;
            j++;
        }
    }




    /*获得链表中的长度*/
    public int size(){
        return this.size;
    }




    public boolean isEmpty(){
        return this.size==0;
    }
    /*插入元素*/
    public void add(int index,Object obj)throws Exception{
        if (index<0 || index>size){
            throw new Exception("参数错误");
        }
        //定位节点
        index(index-1);
        current.setNext(new Node(obj,current.next));
        size++;
    }
    public void remove(int index)throws Exception{
        if (isEmpty()){
         throw new Exception("空链表");
        }
        if (index<0 || index>size-1){
            throw new Exception("参数错误");
        }
        index(index-1);//定位操作
        current.setNext(current.next.next);
        size--;
    }
    public Object get(int index)throws Exception{
        if(index<-1||index >size-1){
            throw new Exception("参数错误");
        }
        index(index);
        return current.getElement();
    }
}
