package com.teacher8_7.Node;
/*定义节点类  两个属性 储存的数据 指向下一个节点的指针*/
public class Node {
    Object element;//保存的数据
    Node next;  //指针
//构造方法
    //头节点
    public Node(Node nextval){
        this.next=nextval;
    }
    //不是头节点
    public Node(Object obj,Node nextval){
        this.element=obj;
        this.next=nextval;
    }
    public Object getElement(){
        return element;
    }

    public void setElement(Object element){
        this.element =element;
    }
    public Node getNext(){
        return next;
    }

    public void setNext(Node next) {
        this.next = next;
    }
}
