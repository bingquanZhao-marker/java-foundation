package com.teacher8_7.Node;

public class NodeTest {
    public static void main(String[] args)throws Exception {
        LinkList list = new LinkList();
        for (int i = 0; i <10 ; i++) {
            list.add(i,"i"+i);
        }
        for (int i = 0; i <list.size ; i++) {
            System.out.println(list.get(i));
        }
    }
}
