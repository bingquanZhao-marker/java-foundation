package com.teacher8_7.Node;

public interface List {
    /*获得链表中的长度*/
    public int size();
    public boolean isEmpty();
    /*插入元素*/
    public void add(int index,Object obj)throws Exception;
    public void remove(int index)throws Exception;
    public Object get(int index)throws Exception;
}
