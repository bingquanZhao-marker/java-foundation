package com.teacher8_7.list;

import java.util.ArrayList;
import java.util.List;

public class ListDemo {
    public static void main(String[] args) {
        List<Person> array = new ArrayList<>();
        System.out.println("&&&&&”+array.isEmpty()");

        array.add(new Person("张三",20));//赋值
        array.add(new Person("李四",20));
        System.out.println(array.remove (new Person("张三",20)));
        array.add(new Person("隔壁老王",30));
        System.out.println(new Person("隔壁老王",30).equals(new Person("隔壁老王",30)));
        //array.add(4);

        for (int i = 0; i < array.size(); i++) {
            System.out.println(array.get(i));//通过get取值
        }
    }
}
//通过使用ArrayLIst发现，其特点是可重复的，并且有序的
//顺序储存储存室的位置，通过add添加元素到集合
//get(index)取出集合2中的元素，下表的位置从0开始