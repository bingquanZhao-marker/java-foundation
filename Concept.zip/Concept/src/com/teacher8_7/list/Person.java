package com.teacher8_7.list;

public class Person implements Comparable<Person> {
    private String name;
    private int age;
    public Person(String name, int age){
        this.age=age;
        this.name=name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        Person per =null;
        if(obj instanceof Person){
            per =(Person)obj;//向下转型为Person类型
        }
        if (this==per){  //this当前对象 person和传进来的Person比较
            return true;
        }
        if(this.age==per.age&&this.name.equals(per.name)){
            return true;
        }
        return false;
    }
    // 覆写
    @Override
    public int compareTo(Person o) {
        if(this.age>o.age){
            return 1;
        }else if (this.age<o.age){
            return -1;
        }
        return 0;

    }
    //重写toString方法
    public String toString(){
        return "名字为"+name+",年龄为"+age;
    }
}
