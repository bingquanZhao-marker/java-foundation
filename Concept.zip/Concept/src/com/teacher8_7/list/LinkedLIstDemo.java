package com.teacher8_7.list;

import java.util.LinkedList;

public class LinkedLIstDemo {
    public static void main(String[] args) {
        LinkedList<String> list =new LinkedList<>();
        list.add("hello");
        list.add("world");
        list.add("java");
        list.addFirst("hadoop");
        list.addLast("hive");
        for (String str:list) {
            System.out.println(str);
        }

    }
}
