package com.teacher8_14.Random;

import java.io.IOException;
import java.io.RandomAccessFile;

public class RandomFileUtils {
    public static void readRandomFile(String filePath)throws IOException {
        RandomAccessFile randomAccessFile = new RandomAccessFile(filePath,"rwd");
        System.out.println(randomAccessFile.getFilePointer());
        randomAccessFile .seek(20);

        String result= randomAccessFile.readLine();
        System.out.println(result);
        randomAccessFile.close();

    }

    public static void main(String[] args) throws IOException {
        readRandomFile("/Users/apple/desktop/newfile/aa.txt");
    }
}
