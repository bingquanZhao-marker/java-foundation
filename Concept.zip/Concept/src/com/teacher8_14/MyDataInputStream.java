package com.teacher8_14;

import java.io.*;

public class MyDataInputStream {
    public static void writeData(String outPath)throws IOException{
        FileOutputStream fileOutputStream =new FileOutputStream(outPath);
        DataOutputStream outputStream =new DataOutputStream(fileOutputStream);
        outputStream.writeInt(23);
        outputStream.writeUTF("hello world");
        outputStream.writeChar(97);;
        fileOutputStream.close();
        outputStream.close();
    }
    public static void readData(String inPath)throws IOException {
        FileInputStream fileInputStream = new FileInputStream(inPath);
        DataInputStream inputStream=new DataInputStream(fileInputStream);
        System.out.println(inputStream.readInt());
        System.out.println(inputStream.readUTF());
        System.out.println(inputStream.readChar());
        fileInputStream.close();
        inputStream.close();
    }

    public static void main(String[] args)throws IOException {
        writeData("");
        readData("");
    }
}
