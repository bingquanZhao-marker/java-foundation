package com.teacher8_14.reader;

import com.teacher8_13.objectInput.Person;

import java.io.*;
import java.util.Scanner;

public class BufferUtils {
public static void copyFile(String from,String to)throws IOException{
    BufferedInputStream inputStream = new BufferedInputStream(new FileInputStream(from));
    BufferedOutputStream outputStream = new BufferedOutputStream(new FileOutputStream(to));
    int len=0;
    byte[] data = new byte[20];
    while ((len=inputStream.read(data))!=-1){
        outputStream.write(data,0,len);
    }
    inputStream.close();
    outputStream.close();
}
public static void readPersonObject() throws IOException{
    FileOutputStream fileInputStream =new FileOutputStream("/Users/apple/desktop/newfile/Person.tmp");
    ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileInputStream);
    objectOutputStream.writeObject(new Person("jack",30));
    BufferedOutputStream bufferedOutputStream =new BufferedOutputStream(objectOutputStream );
    bufferedOutputStream.flush();
    bufferedOutputStream.close();
}
public  static  void copyWordDoc(String from,String to) throws  IOException{

    BufferedReader bufferedReader =new BufferedReader(new FileReader(from));

    Scanner scanner=new Scanner(System.in);
    String str=scanner.nextLine();

    BufferedWriter bufferedWriter=new BufferedWriter(new FileWriter(to,true));
    while(!str.equals("0")) {
        bufferedWriter.write(str);
        str = scanner.nextLine();
    }


        bufferedReader.close();
        bufferedWriter.close();




}

    public static void main(String[] args)  throws IOException {
        //copyFile("/Users/apple/desktop/newfile/aa.png","/Users/apple/desktop/newfilecopy/bb.png");
       // readPersonObject();
        copyWordDoc("/Users/apple/desktop/2233.doc","/Users/apple/desktop/newfile/22.doc");
    }
}
