package com.teacher8_14.reader;

import java.io.*;

/*
* 假设有一个TXT文件，里面存放着大小写数字,使用IO统计出来
* ** */
public class BufferTXTReader {
    public static void readFileByBuffer(String filePath) throws IOException {
        //BufferedReader bufferedReader =new BufferedReader(new InputStreamReader(new FileInputStream(filePath)));
        BufferedReader bufferedReader=new BufferedReader(new FileReader(filePath));
        String value="";
        StringBuilder str =new StringBuilder();
        while((value=bufferedReader.readLine())!=null){
        str.append(value);
        }
        bufferedReader.close();
        System.out.println(str.toString());

    }
    public  static void main(String[] args){

    }
}
