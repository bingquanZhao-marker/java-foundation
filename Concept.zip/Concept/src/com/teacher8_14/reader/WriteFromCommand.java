package com.teacher8_14.reader;

import java.io.*;
import java.util.Scanner;

public class WriteFromCommand {
    public static void main(String[] args)throws IOException {
        Scanner scanner = new Scanner(System.in);
        String value=scanner.nextLine();
        writeString(value,"/Users/apple/desktop/newfile/copyfile.txt");


    }
    public static void writeString(String value,String to) throws IOException {
        BufferedReader reader =new BufferedReader(new StringReader(value));
        BufferedWriter writer = new BufferedWriter(new FileWriter(to));
        File file=new File(to);
        if(!file.exists()) {
        file.mkdir();
        }else {


               StringBuilder stringBuilder =new StringBuilder();
               char ch[] =new char[20];
            while ((reader.read(ch))!=-1) {
                stringBuilder.append(ch);

            }
            writer.write(stringBuilder.toString());
            reader.close();
            writer.close();
        }

    }


}
