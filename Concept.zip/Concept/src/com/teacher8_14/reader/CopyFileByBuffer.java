package com.teacher8_14.reader;

import java.io.*;
import java.nio.charset.Charset;
import java.util.Scanner;

public class CopyFileByBuffer {
    public static void copyFile(String from,String to) throws IOException {
        BufferedReader bufferedReader = new BufferedReader(new FileReader(from));
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(to));
        String value="";
        while((value=bufferedReader.readLine())!=null){
            bufferedWriter.write(value);
        }
        bufferedReader.close();
        bufferedWriter.close();

    }
    public static void copy2(String from,String to)throws IOException{
        InputStreamReader inputStreamReader= new InputStreamReader(new FileInputStream(from), Charset.forName("utf-8"));
        OutputStreamWriter outputStreamWriter= new OutputStreamWriter(new FileOutputStream(from),Charset.forName("utf-8"));
        int len = 0;
        char[] ch=new char[20];
        while ((len=inputStreamReader.read(ch))!=-1){
            outputStreamWriter.write(ch,0,len);
        }
        inputStreamReader.close();
        outputStreamWriter.close();
    }
    public static void copy3(String from,String to)throws IOException{
        FileReader reader =new FileReader(from);
        FileWriter writer = new FileWriter(to);
        int len = 0;
        char[] ch =new char[10];
        while ((len = reader.read(ch))!=-1){
            writer.write(ch,0,len);
        }
        reader.close();
        writer.close();
    }
    public static void main(String[] args) throws IOException {
        //copyFile("/Users/apple/desktop/aa.txt","/Users/apple/desktop/bb.txt");
        Scanner scanner = new Scanner(System.in);
        String value =scanner.nextLine();
        System.out.println(value);
    }
}
