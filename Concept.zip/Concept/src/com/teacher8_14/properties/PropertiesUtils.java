package com.teacher8_14.properties;

import javax.swing.*;
import javax.swing.plaf.basic.BasicButtonListener;
import javax.swing.plaf.basic.BasicOptionPaneUI;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.*;

/*操作属型文件 .properties*/
public class PropertiesUtils {
    //将集合集合HashTable中的Key和Value存放到一个属性文件中
    public static void storeHashTableTOFile(Hashtable<String,String> hashtable,String filePath)throws IOException {
        File file =new File(filePath);
        if(!file.exists()){
            file.mkdirs();
        }
        //file表示的是/Users/apple/desktop/student/ecce19e2d1b4c25bb39ab178.properties
        Properties properties = new Properties();
       FileOutputStream outputStream = new FileOutputStream(file.getAbsolutePath()+File.separator+getRandomFileName()+".properties");
       for(Map.Entry<String,String> entry:hashtable.entrySet()){
           properties.setProperty(entry.getKey(),entry.getValue());
       }
       /*Set<Map.Entry<String,String>> set=hashtable.entrySet();
       Iterator<Map.Entry<String,String>> iterator = set.iterator();
       while(iterator.hasNext()){
           Map.Entry<String,String> entry =iterator.next();
           properties.setProperty(entry.getKey(),entry.getValue());
       }*/
        properties.store(outputStream,"this is student recorder");
    }
    public static String getRandomFileName(){
        return UUID.randomUUID().toString().replaceAll("-","").substring(1,25);
    }
    public static void show(){
        JFrame frame = new JFrame();
        frame.setTitle("注册界面");
        frame.setDefaultCloseOperation(3);
        frame.setSize(300,600);
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);
        JLabel L1 = new JLabel("账号");
        JTextField textField =new JFormattedTextField(30);
        JLabel L2 = new JLabel("设置密码");
        JPasswordField passwordField =new JPasswordField(30);
        passwordField.setEchoChar('*');
        frame.add(L1);
        frame.add(L2);
        frame.add(textField);
        frame.add(passwordField);

        JButton button =new JButton("开始注册");
        //BasicButtonListener li1=new BasicButtonListener(new JButton(textField));
    }





    public static void main(String[] args)throws IOException {
        Hashtable<String,String> hashtable = new Hashtable<>();
        hashtable.put("name","jack");
        hashtable.put("age","30");
        hashtable.put("address","北京");
        storeHashTableTOFile(hashtable,"/Users/apple/desktop/newfile/student");
        System.out.println(getRandomFileName());
    }
}
