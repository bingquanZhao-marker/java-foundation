package com.anonymousClass;

public class Person {
    public void driverCar(Car car){
        car.driver();
    }

    public static void main(String[] args) {
        Person person =new Person();
        person.driverCar(new Car() {
            @Override
            public void driver() {

            }
        });
    }
}
