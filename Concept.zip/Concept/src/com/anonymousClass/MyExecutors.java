package com.anonymousClass;



import java.util.concurrent.*;

public class MyExecutors {
    public static void main(String[] args) {
        ExecutorService server = Executors.newFixedThreadPool(4);
        Future<Integer> future=server.submit(new Callable<Integer>() {
            @Override
            public Integer call() {
                return 45;
            }
        });
        try {
            System.out.println(future.get());
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }
    }
}
