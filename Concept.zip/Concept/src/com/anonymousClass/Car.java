package com.anonymousClass;

public interface Car {
    public void driver();
}
