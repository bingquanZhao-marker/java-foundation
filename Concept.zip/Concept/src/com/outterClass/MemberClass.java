package com.outterClass;

public class MemberClass {
    private int age;
}
