package com.teacher8_22_net;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

/**
 *
 */

public class HTTPUtils {
    public static void main(String[] args) {
        String www="http://www.baidu.com";
        try {
            URL url = new URL(www);
            //获取URL的默认端口80
            System.out.println("--------->"+url.getDefaultPort());
            //获取主机名称
            System.out.println("--------->"+url.getHost());
            //获取当前访问的协议
            System.out.println("--------->"+url.getProtocol());
            System.out.println("--------->"+url.getUserInfo());
            System.out.println("--------->"+url.getPath());
            //打开链接准备读取数据
            url.openConnection();


        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
