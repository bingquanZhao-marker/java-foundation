package com.teacher8_22_net;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class ThreadHTTPUtils implements  Runnable {
    private String url_path;
    private DefaultHttpClient httpClient;
    private  String out_path;



    public ThreadHTTPUtils(String url_path,String out_path) {
        this.url_path = url_path;
        this.out_path=out_path;
        httpClient = new DefaultHttpClient();
    }

    @Override
    public void run() {
        HttpGet httpGet = new HttpGet(url_path);
        HttpResponse httpResponse =null;
        BufferedOutputStream outputStream =null;
        try {

            httpResponse = httpClient.execute(httpGet);
            outputStream=new BufferedOutputStream(new FileOutputStream(out_path));
            if(httpResponse.getStatusLine().getStatusCode()==200){
                HttpEntity httpEntity = httpResponse.getEntity();
                httpEntity.writeTo(outputStream);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            if(outputStream!=null) {
                try {
                    outputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
