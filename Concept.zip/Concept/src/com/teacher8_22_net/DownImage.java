package com.teacher8_22_net;


import java.io.*;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class DownImage {
    private URL url;

    public DownImage(String imagePath) {
        try {
            url = new URL(imagePath);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
    }


    public void downLoadImage(String outPath) {
        InputStream inputStream = null;
        FileOutputStream outputStream = null;
        String urlFile = url.getFile();
        System.out.println("---->>"+urlFile);
        //截取文件的完整名称   /img/bd_logo1.png
        String fileName = urlFile.substring(urlFile.lastIndexOf("/",urlFile.length()));
        System.out.println("---fileName--->>" + fileName);
        try {
            //打开url的链接准备访问指定的资源
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            //urlConnection.connect();
            //打开输入输出流
            urlConnection.setDoInput(true);
            urlConnection.setDoOutput(true);
            //从url中获取一个InputStream的对象，该对象表示从网络中读取数据
            inputStream = urlConnection.getInputStream();
            //保存到本地
            outputStream = new FileOutputStream(outPath + File.separator + fileName);
            byte[] data = new byte[20];
            int len = 0;
            while ((len = inputStream.read(data)) != -1) {
                outputStream.write(data, 0, len);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (outputStream != null) {
                try {
                    outputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }


    }

    public static void main(String[] args) {
        String baidu = "https://www.baidu.com/img/bd_logo1.png";
        DownImage downImage =new DownImage(baidu);
        downImage.downLoadImage("/Users/apple/desktop/newfile/");

    }
}

