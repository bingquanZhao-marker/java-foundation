package com.teacher8_22_net;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;


import java.io.FileOutputStream;
import java.io.IOException;

public class HTTPClientUtils {
    private DefaultHttpClient httpClient;

    public HTTPClientUtils() {
        httpClient=new DefaultHttpClient();
    }
    public void downLoad(String url_image,String out_path){
        //执行get请求
        HttpGet httpGet = new HttpGet(url_image);
        FileOutputStream outputStream =null;
        try {
            //获取结果，在HTTPResponse中响应
            outputStream=new FileOutputStream(out_path);
            HttpResponse httpResponse = httpClient.execute(httpGet);
            if (httpResponse.getStatusLine().getStatusCode()==200){
                //取出响应的内容
                HttpEntity httpEntity =httpResponse.getEntity();
                httpEntity.writeTo(outputStream);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            if(outputStream!=null){
                try {
                    outputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public static void main(String[] args) {
        String baide ="http://www.baidu.com/img/bd_logo1.png";
        HTTPClientUtils httpClientUtils = new HTTPClientUtils();
        httpClientUtils.downLoad(baide,"/Users/apple/desktop/newfile/baidu.png");


    }
}
