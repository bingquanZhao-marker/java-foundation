package com.teacher8_22_net;

public class TestThreadUtils {
    public static void main(String[] args) {
        String baide ="http://www.baidu.com/index.html";
        ThreadHTTPUtils threadHTTPUtils =new ThreadHTTPUtils(baide,"/Users/apple/desktop/newfile/xxxx.txt");

        Thread thread = new Thread(threadHTTPUtils);
        thread.start();

    }
}
