package com.teacher8_22_net.regular;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 工具类
 */
public class RegularUtils {
    //从网页index中爬取出URL
    private static String regex ="(?<!\\d)(?:(?:[a-zA-z]+://[^\\s|^\\u4e00-\\u9fa5]*))";

    public static List<String> checkUrlByRegular(String content){
        List<String> list = new ArrayList<>();
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher=pattern.matcher(content);
        while(matcher.find()){
            String find_result = matcher.group();
            System.out.println("----->"+find_result);
            list.add(find_result);
        }
        return list;
    }
}
