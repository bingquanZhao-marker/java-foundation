package com.teacher8_22_net.regular;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.concurrent.Callable;

/**
 * 主要是实现下载网络数据，并返回一个String的内容
 */

public class DownLoadCallable implements Callable<String> {
    private String path;
    private DefaultHttpClient httpClient;


    public DownLoadCallable(String path) {
       this.path =path;
       httpClient = new DefaultHttpClient();
    }

    /**
     *
     * @return String
     */

    @Override
    public String call(){
        HttpGet httpGet =new HttpGet(path);
        HttpResponse httpResponse =null;

        try {
            httpResponse = httpClient.execute(httpGet);
        } catch (IOException e) {
            e.printStackTrace();
        }
        //判断响应后获得的statuline里面的statucode是否为200
        if (httpResponse.getStatusLine().getStatusCode()== HttpStatus.SC_OK){

            HttpEntity httpEntity =httpResponse.getEntity();
            try {
                return  EntityUtils.toString(httpEntity, Charset.forName("utf-8"));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return null;
    }
}
