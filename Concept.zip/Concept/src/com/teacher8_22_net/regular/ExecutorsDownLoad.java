package com.teacher8_22_net.regular;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class ExecutorsDownLoad {
    private ExecutorService service;

    /**
     * 构造方法实例化线程池
     */
    public ExecutorsDownLoad() {
        service = Executors.newFixedThreadPool(3);
    }

    /**
     * 获取网页的内容
     * @param path  网页的URL
     * @return
     */
    public String getContent(String path){
        Future<String> future=service.submit(new DownLoadCallable(path));


        try {
            return future.get();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }finally {
            service.shutdown();
        }
        return "";
    }

    public static void main(String[] args) {
        ExecutorsDownLoad downLoad = new ExecutorsDownLoad();
       String result= downLoad.getContent("http://apache.org/index.html");
       WriteFile writeFile = new WriteFile();
       writeFile.writeFile(RegularUtils .checkUrlByRegular(result));

    }
}
