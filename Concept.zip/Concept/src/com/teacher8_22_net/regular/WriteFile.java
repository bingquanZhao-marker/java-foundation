package com.teacher8_22_net.regular;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class WriteFile {
    /**
     * 将list 写入TXT文件中
     * @param list
     */
    public  void writeFile(List<String> list){
               try{
                    BufferedWriter writer =new BufferedWriter(new FileWriter("/Users/apple/desktop/newfile/justdo.txt",true));
                    if(!list.isEmpty()){
                        for (String s : list) {
                            writer.write(s);
                            writer.newLine();
                        }
                    }
                    writer.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }

        }
    }

