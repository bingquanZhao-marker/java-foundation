package com.socket.practise;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class FileServer implements Runnable {
private final int SERVER_PORT=55533;

private ServerSocket serverSocket;

private  String from;

    public FileServer(String from) {
        try {
            serverSocket =new ServerSocket(SERVER_PORT);
            this.from=from;

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @Override
    public void run() {
        sendFile();
    }
    public void sendFile(){
      Socket socket =null;
      FileInputStream fileInputStream =null;
      OutputStream outputStream =null;

        try {
            System.out.println("服务器已经打开，正在等到客户端");
            socket=serverSocket.accept();
            fileInputStream =new FileInputStream(from);
            outputStream =socket.getOutputStream();
            byte[] data= new byte[1024];
            int len=0;
            while((len=fileInputStream.read(data))!=-1) {
                outputStream.write(data, 0, len);
            }
            socket.shutdownOutput();

        } catch (IOException e) {
            e.printStackTrace();
        }finally {

            try {
                if(!serverSocket.isClosed()) {
                    serverSocket.close();
                }
                if(fileInputStream!=null){
                    fileInputStream.close();
                }
                if(outputStream!=null){
                    outputStream.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }


    }



}
