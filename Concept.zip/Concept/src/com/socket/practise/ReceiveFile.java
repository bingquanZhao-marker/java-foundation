package com.socket.practise;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ReceiveFile {
    public ReceiveFile(String to) {
        ExecutorService service = Executors.newFixedThreadPool(3);
        service.submit(new FileClient(to));
        service.shutdown();
    }

    public static void main(String[] args) {
        new ReceiveFile("/Users/apple/desktop/newfile/day05.txt");
    }
}
