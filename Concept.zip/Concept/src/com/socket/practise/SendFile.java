package com.socket.practise;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
public class SendFile {
    public SendFile(String from) {
        ExecutorService service = Executors.newFixedThreadPool(3);
        service.submit(new FileServer(from));


        service.shutdown();
    }

    public static void main(String[] args) {
      new SendFile("/Users/apple/desktop/newfile/123.txt");
    }
}
