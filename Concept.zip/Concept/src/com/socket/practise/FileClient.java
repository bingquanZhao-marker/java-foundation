package com.socket.practise;

import java.io.*;
import java.net.Socket;

public class FileClient implements Runnable{
    private final int SOCKET_PORT=55533;
    private final String HOST_NAME="127.0.0.1";
    private Socket socket;
    private String to;

    public FileClient(String to) {
        try {
            socket = new Socket(HOST_NAME,SOCKET_PORT);
            this.to=to;
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {

        acceptFile();
    }
    public void acceptFile(){
    InputStream inputStream =null;
    FileOutputStream fileOutputStream =null;
        try {
            inputStream=socket.getInputStream();
            fileOutputStream =new FileOutputStream(to);
            byte[] data = new byte[1024];
            int len=0;
            while ((len=inputStream.read(data))!=-1) {
                fileOutputStream.write(data,0,len);
            }
            socket.shutdownInput();
        } catch (IOException e) {
            e.printStackTrace();
        }finally {

                try {
                    if(!socket.isClosed()) {
                        socket.close();
                    }
                    if(inputStream!=null){
                        inputStream.close();
                    }
                    if(fileOutputStream!=null){
                        fileOutputStream.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }



    }
}
