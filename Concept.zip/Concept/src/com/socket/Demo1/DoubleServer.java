package com.socket.Demo1;

import javax.sound.midi.SoundbankResource;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class DoubleServer {
    private final int SERVER_PORT=55533;
    private ServerSocket serverSocket;

    public DoubleServer() {
        try {
            serverSocket = new ServerSocket(SERVER_PORT);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public void receiveMessage(){
        Socket socket =null;
        OutputStream outputStream =null;
        BufferedReader reader =null;
        try {
            System.out.println("等待客户端的连接");
            socket=serverSocket.accept();

            outputStream = socket.getOutputStream();
            outputStream.write("hi,welcome".getBytes("utf-8"));
            socket.shutdownOutput();

            //接受客户端发送的请求
            reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            System.out.println("----客户端发送的消息-->>"+reader.readLine());
            socket.shutdownInput();

        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            try {
                if(outputStream!=null){
                    outputStream.close();
                }

                if(reader!=null){
                    reader.close();
                }

                if(!socket.isClosed()) {
                    socket.close();
                }
                if(!serverSocket.isClosed()){
                    serverSocket.close();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    public static void main(String[] args) {
        DoubleServer doubleServer = new DoubleServer();
        doubleServer.receiveMessage();
    }
}
