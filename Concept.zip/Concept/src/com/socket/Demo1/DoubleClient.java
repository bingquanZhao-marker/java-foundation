package com.socket.Demo1;

import java.io.*;
import java.net.Socket;

public class DoubleClient {
    private final int SOCKET_PORT=55533;
    private final String HOST_NAME="127.0.0.1";
    private Socket socket;

    public DoubleClient() {
        try {
            socket = new Socket(HOST_NAME,SOCKET_PORT);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void sendMessage(){
        BufferedReader reader =null;
        BufferedWriter writer =null;


        try {
            reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            System.out.println("接受服务器发送的消息"+reader.readLine());
            socket.shutdownInput();

            writer =new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            writer.write("小鸭子你好！");
            writer.flush();
            socket.shutdownOutput();


        } catch (IOException e) {
            e.printStackTrace();
        }finally {

                try {
                    if(reader!=null) {
                        reader.close();
                    }
                    if(writer!=null){
                        writer.close();
                    }
                    if(!socket.isClosed()){
                        socket.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }


    }

    public static void main(String[] args) {
        DoubleClient doubleClient = new DoubleClient();
        doubleClient.sendMessage();
    }
}
