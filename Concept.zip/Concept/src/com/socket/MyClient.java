package com.socket;

import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;

/**
 * 客户端访问指定的服务器 端口号：55533
 */
public class MyClient {
    private Socket socket;
    private final int SOCKET_PORT=55533;
    private final String HOST_NAME="10.0.158.248";


    public MyClient() {
        try {
            socket = new Socket(HOST_NAME,SOCKET_PORT);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 向服务器发送数据
     */
    public void  sendMessage(){
        OutputStream outputStream=null;
        try {
            outputStream=socket.getOutputStream();
            outputStream.write("crazy fuck girl".getBytes("utf-8"));
            socket.shutdownOutput();
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            try {
                if(outputStream!=null) {
                    outputStream.close();
                }
                if(!socket.isClosed()){
                    outputStream.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        MyClient myClient =new MyClient();
        myClient.sendMessage();
    }
}
