package com.socket.teacher;

import java.io.*;

import java.net.Socket;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 客户端访问指定的服务器 端口号：55533
 */
public class ExecutorsClient {

    private  Socket socket;
    private final int SERVER_PORT=55533;
    private final String HOST="127.0.0.1";
    private ExecutorService service;

    public ExecutorsClient(){
        try {
            socket = new Socket(HOST,SERVER_PORT);
        } catch (IOException e) {
            e.printStackTrace();
        }

            service = Executors.newFixedThreadPool(1);

    }
    public void sendMessage() {
        while (true) {

            MyClientRun myClientRun = new MyClientRun(socket);
            service.submit(myClientRun);
        }
    }
    public static void main(String[] args) {
        ExecutorsClient client = new ExecutorsClient();
        client.sendMessage();
    }



}
class MyClientRun implements Runnable{

    private Socket socket;

    public MyClientRun(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        Scanner scanner = new Scanner(System.in);
        BufferedWriter writer =null;
        try {
            System.out.println("请输入聊天内容");

            String msg =scanner.nextLine();
            writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            writer.write(msg);
            //socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            try {
                if(writer!=null) {
                    writer.close();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
        }




    }
}
