package com.socket.teacher;

import java.io.BufferedReader;
import java.io.IOException;

import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ExecutorsServer {
private ServerSocket serverSocket;
private ExecutorService executorService;
private Socket socket;
private final int SERVER_SOCKET=55533;
    public ExecutorsServer() {
        try {
            serverSocket = new ServerSocket(SERVER_SOCKET);
            //声明线程池，处理并发访问
            executorService = Executors.newFixedThreadPool(100);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void acceptMessage(){
        //一直监控端口

        while(true){
            try{
                System.out.println("等待服务器的消息");
                //监听服务器的访问
                socket =serverSocket.accept();
                MyRunner runner = new MyRunner(socket);
                executorService.submit(runner);
            }catch (IOException e){

            }

        }

    }

    public static void main(String[] args) {
       ExecutorsServer server =new ExecutorsServer();
       server.acceptMessage();

    }
}
class MyRunner implements  Runnable{
private  Socket socket;
    public MyRunner(Socket socket) {
        this.socket =socket;
    }

    @Override
    public void run() {
        BufferedReader bufferedReader=null;
        try {
            bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            StringBuilder builder =new StringBuilder();
            String value ="";
            while((value =bufferedReader.readLine() )!=null){
                builder.append(value);
            }
            System.out.println("接收到服务器的消息"+builder.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            try {
                if(bufferedReader!=null) {
                    bufferedReader.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }


    }
}