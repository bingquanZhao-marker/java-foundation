package com.socket;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * 编写一个Socket服务端，监听指定的端口号
 */
public class SeverManaget {
    //指定服务端的端口号
    private final int SOCKET_PORT=55533;

    private ServerSocket serverSocket;

    public SeverManaget() {
        try {
            serverSocket = new ServerSocket(SOCKET_PORT);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    /**
     * 接收socket 发送的请求
     */
    public  void acceptMessage(){
        Socket socket=null;
        InputStream inputStream=null;

        try {
            System.out.println("等待客户端的链接");
            //接受从客户端发送的请求
            socket=serverSocket.accept();
            inputStream=socket.getInputStream();
            byte[] data =new byte[1024];
            int len=0;
            StringBuilder builder = new StringBuilder();
            while((len=inputStream.read(data))!=-1){
                builder.append(new String(data,0,len,"utf-8"));
            }
            System.out.println("----接受到客户端的信息---->"+builder.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            if(!socket.isClosed()){
                try {
                    if(!socket.isClosed()) {
                        socket.close();
                    }
                    if(!serverSocket.isClosed()){
                        serverSocket.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public static void main(String[] args) {
        SeverManaget managet =new SeverManaget();
        managet.acceptMessage();
    }
}
