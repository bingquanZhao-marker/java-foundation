package com.teaaher8_11.practise;

public class PrimeNumber {
    public static void main(String[] args) {


        for(int i=2;i<=100;i++){
            boolean b=true;
          int j=2;
                for(j=2;j<i;j++){
                    if(i%j==0){
                        b=false;
                        break;
                    }
                }
                if (b&&i==j){
                    System.out.print(i+" ");
                }

        }
    }
}
