package com.teaaher8_11.practise;

public class Practise1 {
    public static void main(String[] args) {
        String str="the sky is blue";
    }
    public static String reWord(String str){
        int left=0; int right=str.length()-1;
        while(left<=right && str.charAt(left)==' '){
            if(str.charAt(left)==' '){
                left++;
            }
            if(str.charAt(right)==' '){
                right--;
            }
        }
        StringBuilder result =new StringBuilder();
        for(int i=right;i>=left;i--) {
            char c = str.charAt(i);

            if (c == ' ') {
                result.append(str.substring(i + 1, right + 1)).append(" ");

                while (i >= left && str.charAt(i) == ' ') {
                    i--;
                }
                right = i;
            }
        }
        result.append(str.substring(left,right+1));

        return result.toString();
    }
}
