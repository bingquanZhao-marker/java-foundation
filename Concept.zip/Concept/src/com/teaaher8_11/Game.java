package com.teaaher8_11;
    import java.util.*;
    public class Game {
        //声明地图
         Map map=new Map();
        //声明对战中玩家1的当前位置
        int playerPos1;
        //声明对战中玩家2的当前位置
        int playerPos2;
        //声明走或停标识设置
        String[] goAndStop;
        //声明对战角色
        String[] playerName;

        /**
         * 初始化游戏的一局
         */
        public void init(){
       Map map=new Map();     //创建Map对象

        map.showMap(playerPos1,playerPos2);    //生成地图

            playerPos1=0;//设置玩家1起始位置

            playerPos2=0;//设置玩家2起始位置

            int record1=playerPos1;//记录玩家1下一次走或停

            int record2=playerPos2;//设置玩家2下一次走或停
        }


        /**
         * 开始游戏
         */
        public void start(){
          map.createMap();  //调用初始化方法
           map.showMap(playerPos1,playerPos2); //显示游戏界面

           setRole(1,4); //角色设置

            //开始游戏

        }

        /**
         * 设置对战角色
         * @param no 玩家次序 1：玩家1 , 2：玩家2
         * @param role 角色代号
         */
        public void setRole(int no, int role){
            switch(role){
                case 1:
                    playerName[no-1] = "戴高乐";
                    break;
                case 2:
                    playerName[no-1] = "艾森豪威尔";
                    break;//设置玩家名称为"艾森豪威尔"
                case 3:
                    playerName[no-1] = "麦克阿瑟";
                    break;//设置玩家名称为"麦克阿瑟"

                case 4:
                    playerName[no-1] = "巴顿";
                    break;//设置玩家名称为"巴顿"

                default:playerName[no-1]="戴高乐";
                    break;
            }
        }


        /**
         * 两人对战玩法
         */
        public void play(){
            System.out.println("\n\n\n\n");

            System.out.print("\n\n****************************************************\n");
            System.out.print("                     Game  Start                    \n");
            System.out.print("****************************************************\n\n");

            //显示对战双方士兵样式
            System.out.println("^_^" + playerName[0] + "的士兵：　Ａ");
            System.out.println("^_^" + playerName[1] + "的士兵：  Ｂ\n");

            //显示对战地图
            System.out.println("\n图例： " + "■ 暂停  ¤ 幸运轮盘   ★ 地雷   〓 时空隧道   ∷ 普通\n");

            map.showMap(playerPos1, playerPos2);


            //游戏开始
            int step;  //存储骰子数目
            while(playerPos1 < 99 && playerPos2 < 99){	//有任何一方走到终点，跳出循环

                //轮流掷骰子
                if(goAndStop[0].equals("on")){
                    //玩家1掷骰子
                    step = throwShifter(1);   //掷骰子
                    System.out.println("\n-----------------");  //显示结果信息
                    System.out.println("骰子数： "+ step);
                    playerPos1 = getCurPos(1, playerPos1, step);   //计算这一次移动后的当前位置
                    System.out.println("\n您当前位置：  "+ playerPos1);
                    System.out.println("对方当前位置："+ playerPos2);
                    System.out.println("-----------------\n");
                    map.showMap(playerPos1, playerPos2); //显示当前地图
                    if(playerPos1 == 99){  //如果走到终点
                        break;   //退出
                    }
                }else{
                    System.out.println("\n" + playerName[0] +"停掷一次！\n");   //显示此次暂停信息
                    goAndStop[0] = "on";   //设置下次可掷状态
                }


                System.out.println("\n\n\n\n");

                if(goAndStop[1].equals("on")){
                    //玩家2掷骰子
                    step = throwShifter(2); //掷骰子
                    System.out.println("\n-----------------"); //显示结果信息
                    System.out.println("骰子数： "+ step);
                    playerPos2 = getCurPos(2, playerPos2, step);   //计算这一次移动后的当前位置
                    System.out.println("\n您当前位置：  "+ playerPos2);
                    System.out.println("对方当前位置："+ playerPos1);
                    System.out.println("-----------------\n");
                    map.showMap(playerPos1, playerPos2);
                    if(playerPos2 == 99){  //如果走到终点
                        break;   //退出
                    }
                }else{
                    System.out.println("\n" + playerName[1] + "停掷一次！\n");  //显示此次暂停信息
                    goAndStop[1] = "on";  //设置下次可掷状态
                }

                System.out.println("\n\n\n\n");
            }

            //游戏结束
            System.out.println("\n\n\n\n");
            System.out.print("****************************************************\n");
            System.out.print("                      Game  Over                    \n");
            System.out.print("****************************************************\n\n");
            judge();
        }


        /**
         * 掷骰子
         * @param no 玩家次序
         * @return step 掷出的骰子数目
         */
        public int throwShifter(int no){
            //定义变量存储骰子数目
            int step = 0;

            System.out.println("启动骰子");//提示玩家启动掷骰子

            for (step = 1; step <6 ; step++) {
                if(step==1){
                    System.out.println(step);
                }else if(step==2){
                    System.out.println(step);
                }else if(step==3){
                    System.out.println(step);
                }else if(step==4){
                    System.out.println(step);
                }else if(step==5){
                    System.out.println(step);
                }else
                    System.out.println(step);
            }//模拟掷骰子：产生一个1~6的数字作为玩家掷的骰子数目


            return step;
        }



        /**
         * 计算玩家此次移动后的当前位置
         * @param no 玩家次序
         * @param position 移动前位置
         * @param step 掷的骰子数目
         * @return position 移动后的位置
         */
        public int getCurPos(int no, int position, int step){
            position = position + step;  //第一次移动后的位置
            if(position >= 99){
                return 99;
            }
            Scanner input = new Scanner(System.in);
            switch(map.map[position]){   //根据地图中的关卡代号进行判断
                case 0:    //走到普通格
                    if(playerPos1==playerPos2){   //添加条件：玩家1与对方骑兵相遇
                        playerPos2=0;//添加代码实现：踩到对方，对方回到起点

                        System.out.println(":-D  哈哈哈哈...踩到了！");
                    }
                    if (playerPos2==playerPos1){ //添加条件：玩家2与对方骑兵相遇
                        playerPos1=0;//添加代码实现：踩到对方，对方回到起点

                        System.out.println(":-D  哈哈哈哈...踩到了！");
                    }
                    break;
                case 1:   //幸运轮盘
                    System.out.println("\n◆◇◆◇◆欢迎进入幸运轮盘◆◇◆◇◆");
                    System.out.println("   请选择一种运气：");
                    System.out.println("   1. 交换位置  2. 轰炸");
                    System.out.println("=============================\n");
                    int choice  = input.nextInt();
                    int temp; //交换时的临时变量
                    switch(choice){
                        case 1:  //交换位置
                            if(no == 1){
                                temp=position;
                                position=playerPos2;
                                playerPos2=temp;//添加代码实现交换：position与playerPos2数值互换


                            }else if(no == 2){

                                temp=position;
                                position=playerPos1;
                                playerPos1=temp; //添加代码实现交换：position与playPos1数值互换

                            }
                            break;
                        case 2:   //轰炸
                            if(no==1&&playerPos1<6){ //no为1并且玩家2位置小于6
                                //添加代码实现：计算玩家2当前位置
                             playerPos2=position;
                            }else{
                                //添加代码实现：计算玩家2当前位置
                            }
                            if(no==2&&playerPos2<6){   //no为2并且玩家1位置小于6
                                //添加代码实现: 计算玩家1当前位置

                            }else{
                                //添加代码实现：计算玩家1当前位置

                            }
                            break;
                    }
                    break;
                case 2:   //踩到地雷
                    //添加代码实现：踩到地雷退6步
                   position=position-6;
                    System.out.println("~:-(  " + "踩到地雷，气死了...");
                    break;
                case 3:  //下一次暂停一次
                    //添加代码实现：设置下次暂停掷骰子

                    System.out.println("~~>_<~~  要停战一局了。");
                    break;
                case 4:   //时空隧道
                    //添加代码实现：进入时空隧道，加走10步
                    position=position+10;
                    System.out.println("|-P  " + "进入时空隧道， 真爽！");
                    break;
            }

            //返回此次掷骰子后玩家的位置坐标
            if(position < 0){
                return 0;
            }else if(position > 99){
                return 99;
            }else{
                return position;
            }
        }

        /**
         * 显示对战结果
         */
        public void judge(){
            //添加代码
            System.out.println("玩家"+playerName[1]+"现在的位置"+playerPos1);
            System.out.println("玩家"+playerName[2]+"现在的位置"+playerPos1);
        }


}
