package com.teacher8_8.Iterator;

import java.util.*;

public class ListDemo01 {
    public static void main(String[] args) {
        Vector<String> all=new Vector<>();

        all.add("hello");
        all.add("world");
        all.add("continue");
        Iterator<String> iter=all.iterator();
        while(iter.hasNext()){
            String str=iter.next();
            System.out.println(str);
        }
        //foreach输出
        /*for (String str:all
             ) {
            System.out.println(str);
            */
        //枚举输出
        Enumeration<String> enm= all.elements();//获得枚举输出接口
        while(enm.hasMoreElements()) {//判断是否有下一个元素
            String str = enm.nextElement();//取出元素
            System.out.println(str);
        }
        }
     }



