package com.teacher8_8.defaultTest;

public class MyLIstImpl implements Mylist {
    public void add(){

    }
    public void update(){

    }
    public void remove(){
        System.out.println("hello");
    }
}
