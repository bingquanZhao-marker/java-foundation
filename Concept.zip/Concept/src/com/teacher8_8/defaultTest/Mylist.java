package com.teacher8_8.defaultTest;

public interface Mylist {
    public void add();
    public void update();
    default void remove(){
        System.out.println("hello");
    }
}
