package com.teacher8_8.Map;

import java.util.Map;
import java.util.TreeMap;

public class TreeMapDemo {
    public static void main(String[] args) {
        Map<Student, Integer> all = new TreeMap<>();
        all.put(new Student("张三", 20, 30), 3);
        //all.put("B",4);
        //all.put("A",5);
        System.out.println(all.toString());
    }

    public static class Student implements Comparable<Student> {
        String name;
        int age;
        double score;

        public Student(String name, int age, double score) {
            this.name = name;
            this.age = age;
            this.score = score;
        }

        @Override
        public String toString() {
            return "名字"+name+"年龄"+age+"成绩"+score;
        }

        @Override
        public int compareTo(Student stu) {
            if(this.age<stu.age){
                return 1;
            }else if(this.age>stu.age){
                return -1;
            }
            return this.name.compareTo(stu.name);
        }
    }
}
