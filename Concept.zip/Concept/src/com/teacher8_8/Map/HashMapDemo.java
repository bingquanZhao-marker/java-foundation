package com.teacher8_8.Map;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class HashMapDemo {
    public static void main(String[] args) {
        Map<String,Integer> all=new HashMap<>();
        //通过put方法赋值到map
        all.put("one",1);
    all.put("two",2);
    all.put("three",3);

       //1.将map集合转换为Set集合
       Set<Map.Entry<String,Integer>> set=all.entrySet();
        //2.遍历set集合
        Iterator<Map.Entry<String,Integer>> iter=set.iterator();
        //循环取出迭代器中的内容
        while (iter.hasNext()){
            Map.Entry<String,Integer> me=iter.next();
            System.out.println(me.getKey());//取出key的方法
            System.out.println(me.getValue());//取出value的方法
        }
    }

}
/*在HashMap中，key是不能重复的，value是可以重复的,如果出现相同的key,
 前面相同的就会被覆盖掉*/
