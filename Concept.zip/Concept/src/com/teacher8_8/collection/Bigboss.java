package com.teacher8_8.collection;

public class Bigboss {
    public static final int Bigboss=0;
    public  static  final int not_Bigboss=1;
}
