package com.teacher8_8.collection;



import java.util.*;


public class Game {

    public static void main(String[] args) {

        HashMap<Integer, String> poke = new HashMap<>();
        ArrayList<Integer> array = new ArrayList<>();
        String[] colors = {"♠️", "♣️", "♥️️", "♦️"};
        String[] numbers = {"3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A", "2"};
        int index = 0;//定义编号
        for(String number:numbers){
            for (String color:colors){
                poke.put(index,color.concat(number));
                array.add(index);
                index++;
            }
        }


        //将大王和小王储存到poke中
        poke.put(index, "大王");
        array.add(index);
        index++;
        poke.put(index, "小王");
        array.add(index);
        Collections.shuffle(array);//调用方法将array中的牌面随机交换
        //TreeSet可以实现排序
        TreeSet<Integer> player1 = new TreeSet<>();
        TreeSet<Integer> player2 = new TreeSet<>();
        TreeSet<Integer> player3 = new TreeSet<>();
        TreeSet<Integer> lastthree = new TreeSet<>();
        TreeSet<Integer> dizhupai =new TreeSet<>();

        for (int i = 0; i < array.size(); i++) {
            if (i >= array.size() - 3) {
                lastthree.add(array.get(i));
            } else if (i % 3 == 0) {
                player1.add(array.get(i));
            } else if (i % 3 == 1) {
                player2.add(array.get(i));
            } else if (i % 3 == 2) {
                player3.add(array.get(i));
            }


        }
        Integer[] keys=poke.keySet().toArray(new Integer[0]);
        Random random=new Random();
        Integer randomkey=keys[random.nextInt(keys.length)];
        dizhupai.add(randomkey);
        

        PrintPoker("底牌",lastthree,poke);
        PrintPoker("玩家1",player1,poke);
        PrintPoker("玩家2",player2,poke);
        PrintPoker("玩家3",player3,poke);
        PrintPoker("地主牌",dizhupai,poke);


}
public static void PrintPoker(String name,TreeSet<Integer> ts,HashMap<Integer,String> hm){
    System.out.println(name+"  ");
    for (Integer key:ts) {
        String value =hm.get(key);

        System.out.print(value+"  ");
    }
    System.out.println();
    }
}






