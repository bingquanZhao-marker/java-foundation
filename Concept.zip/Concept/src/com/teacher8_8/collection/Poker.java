package com.teacher8_8.collection;

public class Poker implements Comparable<Poker> {
     String color;
     String name;
     Integer num;
   public Poker(String color){
       this.color=color;
   }
   public Poker(Integer num ){
       this.num=num;
   }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public int compareTo(Poker o) {
        return this.num-o.num;




    }
}
