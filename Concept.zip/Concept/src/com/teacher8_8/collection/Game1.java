
package com.teacher8_8.collection;


import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Game1 {
    public static void main(String[] args) {
        Set<Poker> pk = new HashSet<>();
        String[] colors = {"♠️", "♣️", "♥️️", "♦️"};
        String[] numbers = {"3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A", "2"};
        ArrayList<Integer> array = new ArrayList<>();


    }
}



