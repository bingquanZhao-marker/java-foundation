package com.teacher8_8.collection;


import java.util.List;

public class Player {
    private String rolename;
    private String roleType;
    private List<Poker> pokerList;
    public Player(String rolename,String roleType){
        this.rolename=rolename;
        this.roleType=roleType;
    }

    public String getRolename() {
        return rolename;
    }

    public void setRolename(String rolename) {
        this.rolename = rolename;
    }

    public String getRoleType() {
        return roleType;
    }

    public void setRoleType(String roleType) {
        this.roleType = roleType;
    }

    public List<Poker> getPokerList() {
        return pokerList;
    }

    public void setPokerList(List<Poker> pokerList) {
        this.pokerList = pokerList;
    }
}
