package com.teacher8_8.collection;

import java.util.*;

public class CardsDemo {
    //定义基本属性

    //1.随机牌的储存
    List<String> cardList =new ArrayList<>();
    //底牌组
    private List<String> bottomCards=new ArrayList<>();
    //地主牌组
    private String LandCard=null;

    //随机数类
    private Random rm=new Random();

    //定义玩家<容器>
    private List<String> playA=new ArrayList<>();
    private List<String> playB=new ArrayList<>();
    private List<String> playC=new ArrayList<>();

    //定义随机牌组的生成方法
    public Set<String> getCardset(){

        Set<String> cardSet=new HashSet<>();//随机的Set牌组，去重功能

       Map<String,Integer> timescounts =new HashMap<>(); //牌面出现的次数

        List<String> cardColors=getCardColor();//编写方法完成

        List<String> cardValues=getCardValue();

        while(!cardValues.isEmpty()) {//牌组不为空的时候，开始初始化

            String cardColor = cardColors.get(rm.nextInt(cardColors.size()));//获取牌面的颜色(随机) 红桃

            String cardValue = cardValues.get(rm.nextInt(cardValues.size()));//获取牌面的值 A


            String card = cardColor + " "+ cardValue;//随机获得一张牌

            if (cardSet.add(card)) {//如果插入底牌成功插入，说明这是第一次

                if (timescounts.containsKey(cardValue)) {//如果牌面不是第一次插入，将牌面的值计数累加
                    timescounts.put(cardValue, timescounts.get(cardValue) + 1);
                    if (timescounts.get(cardValue) == 4) {//如果牌面出现四次
                        cardValues.remove(cardValue);//从牌面值list中删除
                    }
                } else {
                    timescounts.put(cardValue, 1);
                }
            }
        }
        //增加大王小王
        cardSet.add("大王");

        cardSet.add("小王");
        return cardSet;

    }
    //片面值的方法
    public List<String> getCardValue(){
        List<String> cardValue =new ArrayList<>();
        cardValue.add("A");
        cardValue.add("2");
        cardValue.add("3");
        cardValue.add("4");
        cardValue.add("5");
        cardValue.add("6");
        cardValue.add("7");
        cardValue.add("8");
        cardValue.add("9");
        cardValue.add("10");
        cardValue.add("J");
        cardValue.add("Q");
        cardValue.add("K");

        return cardValue;

    }


    public List<String> getCardColor(){
        List<String> cardColor =new ArrayList<>();
        cardColor.add("梅花");
        cardColor.add("红桃");
        cardColor.add("黑桃");
        cardColor.add("方片");

        return cardColor;
    }
    //发牌程序
    public void decard(){

        cardList=new ArrayList<>(getCardset());
        //获取三张底牌
        while (bottomCards.size()<3){
            //从随机牌组中抽出一张牌 放到底牌组
            bottomCards.add(cardList.remove(rm.nextInt(cardList.size())));
        }
        //从剩余牌组中抽出一张地主牌
        LandCard=cardList.get(rm.nextInt(cardList.size()));

        System.out.println("地主牌是"+LandCard);

        //循环发牌给玩家

        int cardNum = cardList.size();

        System.out.println("发牌开始");
        for (int i = 1; i <cardNum ; i++) {
            if (i%3==0){
                playC.add(cardList.get(i-1));
            }else if (i%3==1){
                playB.add(cardList.get(i-1));
            }else{
                playA.add(cardList.get(i-1));
            }
        }
        System.out.println("发牌结束");

        System.out.println("底牌是"+bottomCards);

        if (playA.contains(LandCard)){
            System.out.println("地主是玩家A");
            while(!bottomCards.isEmpty()){
                playA.add(bottomCards.remove(0));
            }
        }else if(playB.contains(LandCard)){
            System.out.println("地主是玩家B");
            while (!bottomCards.isEmpty()){
                playB.add(bottomCards.remove(0));
            }
        }else{
            System.out.println("地主是玩家C");
            while(!bottomCards.isEmpty()){
                playC.add(bottomCards.remove(0));
            }
        }

    }
    public static void show(List<String> list){
        System.out.println("【");
        int count=0;
        while (!(list.size()==1)){
            count++;
            System.out.print(list.remove(0)+"、");
            if (count%6==0){
                System.out.println();
            }
        }
        System.out.println(list.remove(0)+"】");
    }

    public static void main(String[] args) {
        CardsDemo card = new CardsDemo();
        card.decard();

        System.out.println("玩家A的手牌是");
        show(card.playA);
        System.out.println("玩家B的手牌是");
        show(card.playB);
        System.out.println("玩家C的手牌是");
        show(card.playC);
    }
}
