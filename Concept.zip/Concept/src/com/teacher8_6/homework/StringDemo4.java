package com.teacher8_6.homework;

public class StringDemo4 {
    public static void main(String[] args) {
        String str ="the sky is bule";
        System.out.println(reWord(str));
    }

    //  the sky is blue
    public static  String reWord(String str) {
        //消除空格
        int left=0,right=str.length()-1;

        while (left<=right && (str.charAt(left)==' ')||(str.charAt(right)==' ')){
           if(str.charAt(left)==' '){
               left++;
           }
           if (str.charAt(right)==' '){
               right--;
           }
        }
        //判断是否为一个空字符
        if(left>right){
            return "";
        }
        StringBuilder result = new StringBuilder();//保存反转之后的结果
        for(int i=right;i>=left;i--){
            char c=str.charAt(i);
            if (c==' '){
                result.append(str.substring(i+1,right+1)).append(" ");

                while(i>=left&& str.charAt(i)==' '){
                    i--;
                }
                right=i;
            }
        }
        result.append(str.substring(left,right+1));

        return result.toString();
    }


}
