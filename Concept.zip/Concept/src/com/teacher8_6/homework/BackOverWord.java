package com.teacher8_6.homework;

public class BackOverWord {
    public static void main(String[] args) {
        StringBuffer str=new StringBuffer("   hello  world    every day   ");

        backWord(str);


    }


    public static String getRidOfSpace(String string) {


        int l = 0;

        String a = new String();
        String b = new String();
        while (string.charAt(l) == ' ') {
            a = string.substring(l + 1);
            l++;

        }
        //System.out.println(a);
        int r = a.length() - 1;
        while (a.charAt(r) == ' ') {
            b = a.substring(0, r);
            r--;

        }
        return b;


    }
    //算法描述：
    //反向遍历数组
    // 遇到字符记录位置index1，遇到下一个时空格记录位置index2,
    // 使用substring(index2+1,index1+1)
    //截取的一个单词放入StringBuffer String中，加入空格“ ”，循环

    public static void backWord(StringBuffer str) {
        int index1=0,index2=0;
        while (index1<index2) {
            for (int i = str.length() - 1; i >= 0; i--) {

                if (str.charAt(i) != ' ') {
                    index1 = i;//记录字符的位置
                    System.out.println(index1);
                    for (int j = index1; j >= 0; j--) {
                        if (str.charAt(j) == ' ') {
                            index2 = j;
                            StringBuffer string = new StringBuffer();
                            string.substring(index2 + 1, index1 + 1);

                        }//

                    }
                }


            }
        }


        }




    }//





