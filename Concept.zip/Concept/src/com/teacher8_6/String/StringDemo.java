package com.teacher8_6.String;

public class StringDemo {
    public static void main(String[] args) {
       /* String str="hello";
        String str1=new String("hello");
        System.out.println(str==str1);*/
       /*String str="hello";
       String str1="hello";
        System.out.println(str==str1);*/
       String str = "hello,world,java";
       String[] array=str.split(",");
       for(int i=0;i<array.length;i++){
           System.out.print(array[i]);
       }
        System.out.println();
    }
}
