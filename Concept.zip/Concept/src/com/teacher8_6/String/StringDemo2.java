package com.teacher8_6.String;

public class StringDemo2 {
    public static void main(String[] args) {
        /*char[] strarray =new char[]{'h','e','l','l','o'};
        System.out.println(new String(strarray));*/
       /* byte[] array ="hello".getBytes();
        for(int i=0;i<args.length;i++){
            System.out.println(array[i]);
        }
        System.out.println(new String(array));*/
        //String string = "110211198802066418";
//       System.out.println(string.charAt(0));
//        System.out.println(string.startsWith("h"));

//        String newstring =string.substring(6,14);
//        System.out.println(newstring);a
       /* String str ="张三.jpg";
                String str1="小帅aassd.via";
                String str2="隔壁老王.jpg";

                int a= str1.lastIndexOf(".");
        System.out.println(str1.substring(0,a));
        */
       /*char[] array ="hello world".toCharArray();
        for (int i = 0; i <array.length; i++) {
            array[i]-=32;

        }
        String str=new String(array);
        System.out.println(str);*/

        Backover("helloworld");


    }

    /* public static boolean isNumber(String str) {

         char[] array = str.toCharArray();
         for (int i = 0; i < array.length; i++) {
             if (array[i] < '0' || array[i] > '9') {
                 return false;
             } else return true;
         }


     }*/
    public static void Backover(String string) {
        char[] array = string.toCharArray();
        int l = 0;
        int r = array.length - 1;
        while (l < r) {

        }

    }


    public static void swap(char[] array, int left, int right) {
        for (left = 0; left < array.length; left++) {

            for (right = array.length - 1; right < 0; right--) {
                char temp = array[left];
                array[left] = array[right];
                array[right] = temp;

            }
        }
    }
}

