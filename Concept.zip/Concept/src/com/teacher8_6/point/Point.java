package com.teacher8_6.point;

public class Point<T> {//T只是一个标记type 可以随便定义
    //T可能是String double int 一切皆有可能
    private T x;
    private  T y;
    public  T getX(){
        return x;
    }
    public void setX(T x){
        this.x =x;
    }
    public  T getY(){
        return  y;
    }
    public void setY(T y){
        this.y=y;
    }
    //以上的类定义了泛型，在使用的时候规定好要存放的类型，则可以避免向下转型造成可能出现的异常
    public static void main(String[] args) {
        //设置一个整数

        Point<Integer> p =new Point();//只能存在int类型
        p.setX(10);
        p.setY(20);

        int x=p.getX();
        int y=p.getY();
        System.out.println("坐标x"+x+" "+"坐标y"+y);
    }

}
