package com.teacher8_6.point;

public class PointS {
    private Object x;
    private Object y;
    public Object getX(){
        return x;
    }
    public void setX(Object x){
        this.x=x;
    }
    public Object getY(){
        return  y;

    }
    public void setY(Object y){
        this.y=y;
    }

    public static void main(String[] args) {
        //设置一个整数
        Point p =new Point();

        p.setX(10);
        p.setY(20);

        int x= (Integer)p.getX();
        int y=(Integer)p.getY();
        System.out.println("坐标x"+x+" "+"坐标y"+y);
    }

}
//以上功能可以接收任意类型，但主要原因是是使用Object类，每次取出的时候都需要向下转型，
//这个时候就存在危险因素