package com.teacher8_6.test;

public class TestDemo2 {

    public static void main(String[] args) {
        fun(new B());
    }

    public static  void fun(A a){
        C c =(C)a;
        c.fun();

    }
}
