package com.teacher8_6.test;
//多态讲解
class A{
    public void fun(){
        System.out.println("public void funA");
    }

}
class B extends A{
    public void fun(){
        System.out.println("public void funB");
    }
    public  void fly(){
        System.out.println("扑腾起来了");
    }
    public  void run(){
        System.out.println("子类独有的类");
    }

}
class C extends A{
    public void fun() {
        System.out.println("c中的方法");

    }
}
public class TestDemo {
    public static void main(String[] args) {
       //向上转型
       //A a = new B();//A类实例化子类对象，调用的是子类的方法，new的是子类的对象
        //父类的方法被子类覆写，调用的是子类的方法*/
       A a =new B();

       if(a instanceof B){
           B b=(B)a;
           b.fly();

       }

        //向下转型需要强制
        B b =(B)a;
       // a.fun();//funb
        b.fun();
        b.run();
        //C c =new C();




    }
}
