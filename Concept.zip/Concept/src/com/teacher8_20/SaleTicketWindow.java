package com.teacher8_20;

public class SaleTicketWindow implements  Runnable {
    private int ticket =100;//初始有100张票
    Object object =new Object();

    //同步方法，同步代码模块，同步对象锁
    @Override
    public void run() {
        while(ticket>0){
            saleTicket();
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
    public  void saleTicket(){
        synchronized (object) {
            if(ticket > 0) {

                System.out.println(Thread.currentThread().getName() + "--窗口 卖了第-->" + ticket + "票");
                System.out.println("-------------------------");
                ticket--;

            }else{
                System.out.println("票已经卖完了");
                return;
            }
        }
    }
}
