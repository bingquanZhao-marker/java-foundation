package com.teacher8_20;

import java.util.TimerTask;

public class TimerDemo extends TimerTask {


    @Override
    public void run() {


            System.out.println("hello world");


    }
}
