package com.teacher8_20;

import java.util.Timer;

public class TimerTest {
    public static void main(String[] args) {
        Timer timer =new Timer();
        timer.schedule(new TimerDemo(),0,1000l);
    }
}
