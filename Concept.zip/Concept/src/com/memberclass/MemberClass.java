package com.memberclass;

public class MemberClass {
    private  int age =45;

    public void showInnerVar(){
        System.out.println("---调用内部类的成员变量"+new InnerClass("rose").age);
    }

    class InnerClass{
        private String name;
        private int age =20;

        public InnerClass(String name) {
            this.name = name;
        }

        public void printName(){
            System.out.println("外部类的成员变量"+name);
        }
        public void printAge(){
            System.out.println("外部类的成员变量"+new MemberClass().age);
            System.out.println("内部类的成员变量"+age);
        }
    }

    public static void main(String[] args) {
        MemberClass.InnerClass innerClass =new MemberClass().new InnerClass("jack");
        MemberClass.InnerClass innerClass1 =new MemberClass().new InnerClass("jack");
        innerClass.printName();
    }
}
