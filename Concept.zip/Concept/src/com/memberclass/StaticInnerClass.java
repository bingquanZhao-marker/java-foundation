package com.memberclass;

public class StaticInnerClass {
    private static int age = 56;
    private int score = 100;

    public int getAge(){
        return age;
    }

    static class Inner {
    private static int score =300;

        public Inner() {
            System.out.println("静态内部类的构造方法");
        }
        public void print(){
            System.out.println("内部类的方法"+new StaticInnerClass().age);
        }
    }

    public static void main(String[] args){
StaticInnerClass.Inner inner =new StaticInnerClass.Inner();
inner.print();
        System.out.println();

    }

}
