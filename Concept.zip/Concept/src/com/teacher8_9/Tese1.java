package com.teacher8_9;

public class Tese1 {
    public static void main(String[] args) {
        Imessage msg=()->{
            System.out.println("发送的消息");
        };
        msg.sendMessage();
    }
}
