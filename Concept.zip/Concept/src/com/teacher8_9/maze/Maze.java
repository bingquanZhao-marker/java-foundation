package com.teacher8_9.maze;

public class Maze {
    //入口坐标和出口坐标
    private static int startPosI;
    private static int startPosJ;

    //出口的坐标
    private static int endPosI;
    private static int endPosJ;

    //设置入口的坐标
public void setStart(int startPosI,int startPosJ){
    this.startPosI=startPosI;
    this.startPosJ=startPosJ;
}

    //设置出口的坐标
    public void setEnd(int endPosI,int endPosJ){
        this.endPosI=endPosI;
        this.endPosJ=endPosJ;
    }
public static void visPos(int[][] cell,int i,int j) {
    cell[i][j]=1;
    if(i==endPosI&&j==endPosI){
        System.out.println("找到出口了" );
        for (int m = 0; m <cell.length ; m++) {
            for (int n = 0; n <cell[0].length ; n++) {
                if(cell[m][n]==2){
                    System.out.print("2");
                }else if (cell[m][n]==1){
                    System.out.print("#");
                }else{
                    System.out.print(" ");
                }
            }
            System.out.println();
        }

    }
    if(cell[i][j-1]==0){
        visPos(cell,i,j-1);
    }

    if (cell[i][j+1]==0) {
        visPos(cell,i,j+1);
    }

    if (cell[i-1][j]==0)
        visPos(cell,i-1,j);{
    }

    if (cell[i+1][j]==0){
        visPos(cell,i+1,j);
    }

    cell[i][j]=0;
    }


    public static void main(String[] args) {
        int[][] maze={
                {2,2,2,2,2,2,2,2,2},
                {2,0,0,0,0,0,0,0,2},
                {2,0,2,2,0,2,2,0,2},
                {2,0,2,0,0,2,0,0,2},
                {2,0,2,0,2,0,2,0,2},
                {2,0,0,0,0,0,2,0,2},
                {2,2,0,2,2,0,2,2,2},
                {2,0,0,0,0,0,0,0,2},
                {2,2,2,2,2,2,2,2,2}
        };
        Maze m=new Maze();
        m.setStart(1,1);
        m.setEnd(7,7);
        m.visPos(maze,1,1);
    }




}


