package com.teacher8_9;

public interface Imessage {
    public  void sendMessage();
}
