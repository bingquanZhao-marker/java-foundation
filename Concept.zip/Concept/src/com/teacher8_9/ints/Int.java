package com.teacher8_9.ints;

public class Int {//包装一个基本数据类型
    private int data;
    public Int(int data){
        this.data=data;
    }
    public int intValue(){
        return this.data;
    }
}
