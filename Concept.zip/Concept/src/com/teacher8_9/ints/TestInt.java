package com.teacher8_9.ints;

public class TestInt {
    public static void main(String[] args) {
        //Int n=new Int(10);
        //int m=n.intValue();
       // System.out.println(m);
        Integer n=10;//自动装箱
        System.out.println(n);
        System.out.println(11+1l);
        String string=String.valueOf(10);
        System.out.println(string+10);
    }
}
