package com.teacher8_9.QuickSort;

import java.util.Arrays;

public class QuickSort {
    public static void main(String[] args) {
        int[] array=new int[]{49,38,65,97,76,13,27,49};
        quickSort(array,0,array.length-1);
    }


    public static void quickSort(int[] array,int low,int high){
        if(low<high){
            int mid=partition(array,low,high);//取得分区结果
            quickSort(array,mid+1,high);
            quickSort(array,low,mid-1);
        }
    }



    public static int partition(int[] array,int low,int high){
        //取得关键key
        //取得左右下标 i=0,j=length-1;
        //把数组中第一个元素作为关键字
        int key=array[low];
        int i=low,j=high;
        if(low<high){
            //从j开始向左找
            while (i<j){
                while(i<j&&array[j]>key){
                    j--;
                }
                if(i<j){
                    array[i]=array[j];
                    i++;
                }
                while (i<j&&array[i]<=key){
                    i++;
                }
                if (i<j){
                    array[j]=array[i];
                    j--;
                }
            }
            array[i]=key;
            System.out.println("每次排序的结果"+Arrays.toString(array));
        }
        return i;
    }
}
