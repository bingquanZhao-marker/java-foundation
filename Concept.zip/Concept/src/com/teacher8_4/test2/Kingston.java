package com.teacher8_4.test2;

public  abstract class Kingston implements USBInterface {
    public void open(){
        System.out.println("--open--");
    }
//    public void close(){
//        System.out.println("--close--");
//    }
//
//    public static void main(String[] args) {
//        Kingston ton =new Kingston();
//        ton.open();
//        ton.close();
//    }

}
