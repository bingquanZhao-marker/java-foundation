package com.teacher8_4.test2;

public interface USBInterface {
    void open();
    void close();
}
