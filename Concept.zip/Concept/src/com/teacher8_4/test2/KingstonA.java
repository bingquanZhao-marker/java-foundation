package com.teacher8_4.test2;

public class KingstonA extends Kingston{
    public void close(){
        System.out.println("--close--");
    }

    public static void main(String[] args) {
        KingstonA ton =new KingstonA();
        ton.close();

    }
}
