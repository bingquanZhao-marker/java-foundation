package com.teacher8_4.test2;

public class Buyer implements InterfaceC{
    public void buyFood(){
        System.out.println("--buy food--");
    }
    public void buyFruit(){
        System.out.println("--buy fruit--");
    }
    public void buyCar(){
        System.out.println("--buy car--");
    }

    public static void main(String[] args) {
        Buyer buyer =new Buyer();
        buyer.buyFood();
        buyer.buyFruit();
        buyer.buyCar();
    }
}
