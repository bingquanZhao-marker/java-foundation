package com.teacher8_4.test2;

public interface InterfaceC extends InterfaceA,InterfaceB {
    void buyCar();
}
