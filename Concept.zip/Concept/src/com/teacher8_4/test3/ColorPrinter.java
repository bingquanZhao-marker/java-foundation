package com.teacher8_4.test3;

public class ColorPrinter implements Printer {
    public void print(){
        System.out.println("----彩色打印机----");
    }
}
