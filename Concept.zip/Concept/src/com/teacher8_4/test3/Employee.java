package com.teacher8_4.test3;



//在方法中传递的是接口
public class Employee {
    public void printPage(Printer printer){//传递接口
        printer.print();
    }

    public static void main(String[] args) {
        Employee emp =new Employee();
        //多态,父类的引用指向子类的对象，彩色打印机
       Printer printer1 =new WhitePrinter();
       Printer printer2=new ColorPrinter();
       emp.printPage(printer1);
       emp.printPage(printer2);


       
    }
}
