package com.teacher8_4.test3;

public class WhitePrinter implements Printer {
    public void print(){
        System.out.println("--黑白打印机--");
    }
}
