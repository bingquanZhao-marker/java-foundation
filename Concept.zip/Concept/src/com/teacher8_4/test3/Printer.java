package com.teacher8_4.test3;

public interface Printer {
    public void print();//打印的方法
}
