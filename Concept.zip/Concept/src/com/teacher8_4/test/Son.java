package com.teacher8_4.test;

public  class Son extends Father {
    public void driveCar(){
        System.out.println("Son finish father's driveCar method");
    }

    public static void main(String[] args) {
        Son son = new Son();
        son.makeMoney();
        son.farm();
        son.goToCollege();
        son.driveCar();

    }
}
