package com.teacher8_4.test;

public abstract class Gandpa {
    public void farm(){
        System.out.println("Grandpa make in land");


    }
    public void makeMoney(){
        System.out.println("Grandpa make money");
    }

    //定义成抽象的方法
    public abstract void  goToCollege();

}
