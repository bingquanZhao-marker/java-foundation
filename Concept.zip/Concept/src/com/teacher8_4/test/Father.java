package com.teacher8_4.test;

public  abstract class Father extends Gandpa {

    public void farm(){
        System.out.println("father make a farm");
    }
     public void goToCollege(){
         System.out.println("father finish the Grandpa's method");
     }
     public abstract void driveCar();


}
