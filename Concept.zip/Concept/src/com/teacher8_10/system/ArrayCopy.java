package com.teacher8_10.system;

import java.util.Arrays;

public class ArrayCopy {
    public static void main(String[] args) {
        int[] A=new int[]{1,2,3,4,5};
        int[] B=new int[10];
        System.arraycopy(A,0,B,0,A.length);
        System.out.println(Arrays.toString(B));

    }
}
