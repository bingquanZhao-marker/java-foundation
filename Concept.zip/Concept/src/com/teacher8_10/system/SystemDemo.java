package com.teacher8_10.system;


import java.text.SimpleDateFormat;
import java.util.Date;

public class SystemDemo {
    public static void main(String[] args) {
        long time =System.currentTimeMillis();
        Date data =new Date(time);
        SimpleDateFormat smd=new SimpleDateFormat("yyyy-MM-dd-HH:mm:ss");
        String mytimme=smd.format(data);
        System.out.println(mytimme);
    }
}
