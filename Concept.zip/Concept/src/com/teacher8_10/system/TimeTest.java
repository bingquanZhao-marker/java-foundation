package com.teacher8_10.system;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class TimeTest {
    public static void main(String[] args) {
        long starttime=System.currentTimeMillis();
        String str="";
        for (int i = 0; i <3000 ; i++) {
              str+="hello";
        }
        long endtime=System.currentTimeMillis();
        long runtime=endtime-starttime;
        new SimpleDateFormat("mm:ss").format(new Date(runtime));

        System.out.println(runtime);

    }


}
