package com.teacher8_10.myString;

public class StringTest {
    public static void main(String[] args) {
        StringBuffer sbf=new StringBuffer("hello");
        fun(sbf);
        System.out.println(sbf.toString());

    }
    public static void fun(StringBuffer sbf){
        sbf.append("world").append("just").append("go");
    }

}
