package com.teacher8_10.data;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DataTest {
    public static void main(String[] args)throws ParseException {
//        long time=System.currentTimeMillis();
//        System.out.println(new Date(time));
        //System.out.println(new Date());

//          输出字符串形式的时间
//        Date date=new Date();
//        SimpleDateFormat sd=new SimpleDateFormat("yyyy-MM-dd:HH:mm:ss");
//        String time =sd.format(date);//类型的转换，将date类型的时间格式转化为字符串形式
//        System.out.println(time);

        //输入字符串形式的时间
       String time="2018-08-10:14:21:01";
        SimpleDateFormat sd=new SimpleDateFormat("yyyy-MM-dd:HH:mm:ss");//格式化
        Date date =sd.parse(time);//使用Date类中的parse方法转化为字符串
        System.out.println(date);




    }

}
