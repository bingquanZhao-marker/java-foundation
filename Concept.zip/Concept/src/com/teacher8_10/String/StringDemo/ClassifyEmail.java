package com.teacher8_10.String.StringDemo;

public class ClassifyEmail {
    public static void main(String[] args) {
        String string="bingquan_zhao@icloud.com";
        String string2="Date_Classify";
        String regex ="([a-zA-z0-9]+[-|\\.|_]?)@[a-zA-Z0-9]+.+[a-zA-Z]{2,}";
        if(string.matches(regex)){
            System.out.println("格式正确");

        }else{
            System.out.println("格式错误");
        }

    }
}
