package com.teacher8_10.String.StringDemo;

import java.text.SimpleDateFormat;
import java.util.Date;

public class StringDemo {
    public static void main(String[] args)throws Exception {
       /* String str="123";
        if (str.matches("\\d+")){
            System.out.println("是数组");
        }else
        {
            System.out.println("不是数字");
        }

//    }*/
//       String str="123fdfsds54389123bjdviad9";
       //String regex="[a-zA-Z]+";
       // System.out.println(str.replaceAll(regex," "));
        /*String regex2="\\d";
        String[] result=str.split(regex2);
        for(int i=0;i<result.length;i++) {
            System.out.print(result[i] + "/");
        }
*/
        /*String str="aaaab";
        String regex="a+b";
        System.out.println(str.matches(regex));*/
        //验证日期格式是否合法，如果合法 转换为Date类型输出
        //1989-02-06
        String str= "1989-02-06";
        String regex="\\d{4}-\\d{2}-\\d{2}";
        if(str.matches(regex)){

            Date date =new SimpleDateFormat("yyyy-MM-dd").parse(str);
            System.out.println(date);
        }else{
            System.out.println("不合法");
        }

    }
}