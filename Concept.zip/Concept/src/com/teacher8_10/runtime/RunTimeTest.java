package com.teacher8_10.runtime;

public class RunTimeTest {
    public static void main(String[] args) {
        Runtime runtime =Runtime.getRuntime();
        System.out.println("cpu"+runtime.availableProcessors());
        System.out.println("最大可用内存"+runtime.maxMemory());
        System.out.println("可用内存空间"+runtime.totalMemory());
        System.out.println("空闲内存"+runtime.freeMemory());
        String str=" ";
        for (int i = 0; i <500000 ; i++) {
            str+="hello";
        }
        System.out.println("******************");
        System.out.println("cpu"+runtime.availableProcessors());
        System.out.println("最大可用内存"+runtime.maxMemory());
        System.out.println("可用内存空间"+runtime.totalMemory());
        System.out.println("空闲内存"+runtime.freeMemory());
        System.gc();


        System.out.println("***************************");
        System.out.println("CPU:"+runtime.availableProcessors());

        System.out.println("最大可用内存"+runtime.maxMemory());

        System.out.println("可用内存空间"+runtime.totalMemory());

        System.out.println("空闲内存"+runtime.freeMemory());
    }
}
