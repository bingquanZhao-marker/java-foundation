package com.teacher8_10.final_fanally_finalize;

public class Test {
    Test(){
        System.out.println("王峥去嫖娼");
    }

    @Override
    protected void finalize() throws Throwable {
        System.out.println("死在女人肚皮上之前说：还想再来一炮");
    }

    static void fun()throws Exception{

        try {
             throw new Exception();
        }catch (Exception e){
            System.out.println("疯狂干逼");
        }finally {
            System.out.println("疯狂射精");
        }


    }

    public static void main(String[] args)throws Exception {
   Test test =new Test();
   test=null;
   test.fun();
   System.gc();

    }
}
