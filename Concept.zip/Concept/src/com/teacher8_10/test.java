package com.teacher8_10;

public class test {
    private String[][]chessBoard=new String[10][10];

}