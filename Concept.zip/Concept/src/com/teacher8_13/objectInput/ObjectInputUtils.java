package com.teacher8_13.objectInput;

import java.io.*;

public class ObjectInputUtils {

    public static void writeObjectToDisk(Person person,String toPath) {
        FileOutputStream fileOutputStream = null;
        ObjectOutputStream objectOutputStream = null;

        try {
            fileOutputStream = new FileOutputStream(toPath);
            objectOutputStream = new ObjectOutputStream(fileOutputStream);
            objectOutputStream.writeInt(1001);
            objectOutputStream.writeUTF("hello world");
            objectOutputStream.writeObject(person);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
           try {
               if(fileOutputStream !=null){
                   fileOutputStream.close();
               }
               if (objectOutputStream!=null){
                   objectOutputStream.close();
               }
           }catch (IOException e){
               e.printStackTrace();
           }
           }
    }
    public static void readObjectFromDisk(String filePath){
        try {
            FileInputStream fileInputStream = new FileInputStream(filePath);
            ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
            System.out.println(objectInputStream.readInt());
            System.out.println(objectInputStream.readUTF());
            Person person = (Person) objectInputStream.readObject();
            System.out.println(person);
            fileInputStream.close();
            objectInputStream.close();
        }catch (Exception e){
            e.printStackTrace();
        }


        }
    public static void main(String[] args) {
       readObjectFromDisk("/Users/apple/desktop/newfile/123.tmp");
        //writeObjectToDisk(new Person("jack",23),"/Users/apple/desktop/newfile/123.tmp");
    }
}
