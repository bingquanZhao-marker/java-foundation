package com.teacher8_13.inputStreamDemo;

import java.io.*;

public class ByteArrayUtils {
    public static void readString() throws IOException {
        String str="asdfasfa d";
        ByteArrayInputStream inputStream=new ByteArrayInputStream(str.getBytes());
        ByteArrayOutputStream outputStream =new ByteArrayOutputStream();
        int len=0;
        byte[] data=new byte[20];
        while ((len=inputStream.read(data))!=-1){
            outputStream.write(data,0,len);
        }
        System.out.println(outputStream.toString());
    }
    public static void readFile(String filePath){
        FileInputStream inputStream=null;
        ByteArrayOutputStream outputStream =new ByteArrayOutputStream();
        try{
            inputStream=new FileInputStream(filePath);
        int len=0;
        byte[] data=new byte[20];
        while ((len=inputStream.read(data))!=-1) {
            outputStream.write(data, 0, len);
        }
        }catch(FileNotFoundException e){
            e.printStackTrace();
        }catch (IOException e){
            e.printStackTrace();
        }finally {
            try{
                if (inputStream!=null){
                    inputStream.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        System.out.println(outputStream.toString());
    }


    public static void main(String[] args) {
        //readString();
        readFile("/Users/apple/desktop/newfile/123.txt");
    }
}
