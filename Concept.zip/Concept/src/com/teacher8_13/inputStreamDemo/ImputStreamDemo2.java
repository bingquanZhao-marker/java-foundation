package com.teacher8_13.inputStreamDemo;

public class ImputStreamDemo2 {
}
