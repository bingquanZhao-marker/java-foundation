package com.teacher8_13.inputStreamDemo;


import com.teacher8_13.MyFileFilter;

import java.io.*;

public class ReadTXTFile {
    public ReadTXTFile(){

    }

    public void readFileByPathName (String pathName){
       FileInputStream inputStream =null;
        try {
            inputStream = new FileInputStream(pathName);
            //文件指针
            int len=0;
            //字节缓冲区
            byte[] data =new byte[20];

            StringBuilder builder =new StringBuilder();

                while ((len = inputStream.read(data))!=-1){
                    builder.append(new String(data,0,len));
                }
                System.out.println(builder.toString());
            } catch (FileNotFoundException e) {
                e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            try{
                inputStream.close();
            }catch (IOException e){
                e.printStackTrace();
            }

        }
    }
    public static void copyFileByPathName(String fromSrc,String toSrc){
        FileInputStream inputStream=null;//输入流
        FileOutputStream outputStream=null;//输出流
        try {
            inputStream=new FileInputStream(fromSrc);
            outputStream=new FileOutputStream(toSrc);
            int len=0;//文件指针指向文件的开头
            byte[] data=new byte[20];


                while ((len = inputStream.read(data)) != -1) {
                    outputStream.write(data, 0, len);
                }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            if (inputStream!=null){
                try{
                    inputStream.close();
                }catch (IOException e){
                    e.printStackTrace();
                }
            }
            if (outputStream!=null){
                try{
                    outputStream.close();
                }catch (IOException e){
                    e.printStackTrace();
                }
            }
        }
    }
    public static void copyImageByName(String from,String folder,String fileName){
        FileInputStream inputStream=null;
        FileOutputStream outputStream=null;
        File file =new File(folder);
        if (!file.exists()){
            file.mkdir();
        }
        try {
            inputStream =new FileInputStream(from);//原路径
            String real_file_name =file.getAbsolutePath()+File.separator+fileName;//真正的路径为文件路径和
            outputStream=new FileOutputStream(real_file_name);
            int len =0;
            byte[] data =new byte[20];
            while((len=inputStream.read(data))!=-1){
                outputStream.write(data,0,len);
            }
        }catch (FileNotFoundException e){
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
                try {
                    if (inputStream!=null) {
                        inputStream.close();
                    }
                    if (outputStream!=null){
                        outputStream.close();
                    }
                } catch (IOException e){
                    e.printStackTrace();
                }

        }
    }
    //拷贝一个文件夹下所有的文件到指定的目录下
    public static void copyMoreFile(String from,String to){

        File file =new File(to);
        if (!file.exists()){
            file.mkdir();
        }
        //源文件的根目录
        File root_file=new File(from);
        File[] files =root_file.listFiles(new MyFileFilter(".java"));
        for (File file1:files) {

            FileInputStream inputStream =null;
            FileOutputStream outputStream=null;
            try {
                inputStream=new FileInputStream(file1.getAbsolutePath());
                outputStream = new FileOutputStream(file+File.separator+file1.getName());
                int len=0;
                byte[] data =new byte[20];
                while ((len=inputStream.read(data))!=-1){
                    outputStream.write(data,0,len);
                    System.out.println("开始写入");
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }finally {
                try{
                    if (inputStream!=null){
                        inputStream.close();
                    }
                    if (outputStream!=null){
                        outputStream.close();
                    }
                }catch (IOException e){
                    e.printStackTrace();
                }
            }
        }


    }
    public static void main(String[] args) {

      //copyImageByName("/Users/apple/desktop/newfile/aa.png","/Users/apple/desktop/copyfile","bb.png");
       copyMoreFile("/Users/apple/desktop/newfile","/Users/apple/desktop/copyfile2");
    }
}
