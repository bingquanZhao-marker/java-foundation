package com.teacher8_13;

import java.io.File;

import java.io.IOException;

/*文件系统类File*/
public class FileUtils {

    public static void main(String[] args) {
        // /Users/apple/Desktop/io
        //createNewFile("/Users/apple/Desktop/io/aa.txt");
       listAllFile("/Users/apple/Desktop/newfile");
       // filterAllFileByName("/Users/apple/desktop");
       // makeDirs("/Users/apple/desktop/xxx");
        //listMyFile("Users/apple/desktop");
    }
    /*创建一个文件或者创建文件夹*/
    public static  void createNewFile(String filename){
        File file =new File(filename);
        //创建一个文件
        if(!file.exists()){
            try {
                file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }


    }
    public  static void createFileFolder(String folderName){
        File file =new File(folderName);
        if(file.exists()){
            file.delete();
        }
        boolean flag=file.mkdirs();
        if(flag){
            System.out.println("创建文件夹成功");
        }else{
            System.out.println("创建文件夹失败");
        }

    }
    public static void canOperator(String fileName){
        File file =new File(fileName);
        System.out.println(file.canRead());
        System.out.println(file.canWrite());
        //System.out.println(file.canExecute());
        //是否是目录
        System.out.println(file.isDirectory());
        System.out.println(file.isFile());
        System.out.println(file.isHidden());
        System.out.println(file.isAbsolute());

    }
    public static void listAllFile(String fileName){
        File file = new File(fileName);
        if(file.isDirectory()){
            File[] files =file.listFiles();
            //增强for循环
            for (File file1:files) {
                System.out.println("--filename-->"+file1.getName());
                System.out.println("--AbsolutePath-->"+file.getAbsolutePath());
            }
        }

    }
    public static void filterAllFileByName(String fileName){
        File file =new File(fileName);
        if (file.isDirectory()){
            File[] files =file.listFiles(new MyFileFilter(".java"));
            for (File file1:files) {
                System.out.println("--fileName-->"+file1.getName());
                System.out.println("--AbsolutePath-->"+file.getAbsolutePath());
            }

            }
        }
        public static void filterAllFileByName2(String fileName){
            File file = new File(fileName);
            if(file.isDirectory()){
                File[] files =file.listFiles(new MyFileFilter2("TestPackage",".java"));
                for (File file1:files) {
                    System.out.println("-----filename--》"+file1.getName());
                    System.out.println("---AbosolutePath-->"+file.getAbsolutePath());
                }
            }
        }
        public static void listMyFile(String filePath){
        File file =new File(filePath);
        if(!file.exists()){
            File[] files =file.listFiles();
            for (File file1:files) {
                if (file1.isDirectory()){
                    //递归调用
                    listMyFile(file1.getAbsolutePath());
                    System.out.println("-----文件夹名称--》"+file1.getName());
                }else{
                    System.out.println("---文件名称-->"+file.getName());
                }
            }
        }
        }

    public static void makeDirs(String fileName) {
        File file =new File(fileName);
        if(!file.exists()){
            file.mkdirs();
            System.out.println("yes");
        }
    }
    }

