package com.teacher8_13;

import java.io.File;
import java.io.FileFilter;
import java.io.FilenameFilter;
/*文件过滤器，过滤指定的文件后缀名*/

public class MyFileFilter implements FileFilter {
private String suffixName;


    public MyFileFilter(String suffixName) {
        this.suffixName=suffixName;
    }

    @Override
    public boolean accept(File pathname) {
        if (pathname.getName().toLowerCase().endsWith(suffixName)) {
            return true;
        }
        return false;
    }



}
