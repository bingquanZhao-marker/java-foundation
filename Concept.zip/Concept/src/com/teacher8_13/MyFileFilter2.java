package com.teacher8_13;

import java.io.File;
import java.io.FilenameFilter;

public class MyFileFilter2 implements FilenameFilter {

    private String myDir;
    private String myName;

    public MyFileFilter2(String dir,String name){
        this.myDir=dir;
        this.myName=name;
    }
    @Override
    public boolean accept(File dir, String name) {
        if (dir.getName().equalsIgnoreCase(myDir)/*比较时忽略大小写*/ && name.endsWith(myName)) {//name 的结尾是以传进来的参数决定的
            return true;
        }
        return false;
    }
}
