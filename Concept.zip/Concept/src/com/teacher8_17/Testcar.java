package com.teacher8_17;


import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.concurrent.ExecutionException;

public class Testcar {
    //活得类的类型，返回此类的默认构造方法
    public static void demo1() throws Exception{
        //如何获得一个类的类型Class
        //第一种：类型.class
        //Class<?> cls =Car.class;

        //获取Car类的类型
        Class<?> cls =Class.forName("com.teacher8_17.Car");
        //获取指定class的构造方法
        Constructor constructor =cls.getConstructor();
        //Car car = new Car();
        constructor.newInstance();
    }
    //返回某个类的全部构造方法||特定的某个方法
    public static void demo2() throws Exception{
        Class<?> cls =Class.forName("com.teacher8_17.Car");
       //Class<?> cls =Class.forName("java.lang.String");
        Constructor[] constructors =cls.getConstructors();
        for (Constructor constructor : constructors) {
            System.out.println(constructor);
        }
        //类的构造方法重载，如何指定调用某一个类的构造方法
        Constructor constructor=cls.getConstructor(int.class,String.class);
        constructor.newInstance(10,"白色");
    }
    public static void demo3() throws Exception{
        Class<?> cls =Class.forName("com.teacher8_17.Car");

        Constructor constructor =cls.getDeclaredConstructor(String.class,int.class);
        constructor.setAccessible(true);//强行访问私有方法
        Object object=constructor.newInstance("红色",15);
        if (object instanceof Car){
            Car car=(Car)object;
            car.print();
        }
    }
    //使用field方法给Car类中的int类型 userlife赋值
    public static void demo4()throws Exception{
        Class<?> cls =Class.forName("com.teacher8_17.Car");
        Field[] fields = cls.getDeclaredFields();
        for (Field field : fields) {
            System.out.println("属性名"+field.getName());
        }
        Object instance= cls.newInstance();//将实例化的类型赋值给Object类型的instance
        Field field =cls.getDeclaredField("uselife");
        field.setAccessible(true);
        //判断field的数据
  if (field.getGenericType().getTypeName().equals("int")){
          field.setInt(instance,23);
        }else if(field.getGenericType().getTypeName().equalsIgnoreCase("float")){
      field.setFloat(instance,12.f);
  }
        System.out.println(field.getInt(instance));
    }

//访问field给定字段的的value
    public static void demo5() throws Exception{
        Class<?> cls =Class.forName("com.teacher8_17.Car");
        Field field =cls.getDeclaredField("type");
        field.setAccessible(true);
        Object instance =cls.newInstance();
        field.set("2222","七彩虹");
        System.out.println(field.get(null));
    }
    public static void demo6() throws Exception{
        Class<?> cls = Class.forName("com.teacher8_17.Car");
        Method method = cls.getMethod("print");
        method.invoke(cls.newInstance());
    }
    public static void demo7() throws Exception{
        Class<?> cls = Class.forName("com.teacher8_17.Car");


        Method method=cls.getDeclaredMethod("driveCar", String.class, int.class);
        method.setAccessible(true);
        Method[] methods=cls.getDeclaredMethods();
        Object object = method.invoke(cls.newInstance(),"奔驰",15);
        for (Method method1 : methods) {
            System.out.println(method1);
        }
        System.out.println(object);
    }
    public static void demo8() throws Exception{
        Class<?> cls =Class.forName("com.teacher8_17.Car");
        Method method =cls.getDeclaredMethod("buyCar",int.class);
        method.setAccessible(true);
        Object object =cls.newInstance();
        Object result = method.invoke(object,100);
        System.out.println(result);
    }
    public static void demo9() throws Exception{
        Class<?> cls =Class.forName("java.lang.String");
        Constructor[] constructors =cls.getConstructors();
        for (Constructor constructor : constructors) {
            System.out.println(constructor);
        }
        Method[] methods =cls.getMethods();
        for (Method method : methods) {
            System.out.println(method.getName());
        }
    }
    public static void printClassName(String obj) {
        System.out.println("The class of " + obj +
                " is " + String.class.getName());
    }



    public static void main(String[] args)throws Exception {
        //Testcar.demo1();
        //Testcar.demo2();
        //Testcar.demo3();
        Testcar.printClassName(new String());
    }
}

