package com.teacher8_17;
/*声明一个汽车类*/
public class Car {
    /*无参数构造*/
private int uselife;
private String color;
private static String type;


    public Car() {
        System.out.println("无参数构造方法" );
    }

    public Car(int uselife) {
        this.uselife = uselife;
    }

    public Car(int uselife, String color) {
        this.uselife = uselife;
        this.color = color;
        System.out.println(uselife+" "+color);
    }
    private Car(String color,int uselife){
        System.out.println("使用时间："+uselife+"Color:"+color);
    }
    public void print(){

        System.out.println("打印方法");
    }


    public String driveCar(String type,int uselife){
        return "drive"+type+"  life:"+uselife;
    }
    public int  buyCar(int life){
        return life*100;
    }
}

