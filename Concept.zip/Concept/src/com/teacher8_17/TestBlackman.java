package com.teacher8_17;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

public class TestBlackman {
    public <T> T createTOBean(Map<String,Object> map, Class<?> cls)throws Exception{
        Constructor constructor=cls.getConstructor();
        Object instance =constructor.newInstance();
        Field age_field =cls.getDeclaredField("age");
        age_field.setAccessible(true);
        age_field.setInt(instance,Integer.parseInt(map.get("age").toString()));

        Field name_field = cls.getDeclaredField("name");
        name_field.setAccessible(true);
        name_field.set(instance,map.get("name"));
        return (T)instance;
    }
    public <T>T createTOBean(Class<?> cls,Map<String,Object> map)throws Exception{
        //获取class构造方法
        Constructor constructor=cls.getConstructor();
        Object instance =constructor.newInstance();//获取class的实例
        Field[] fields =cls.getDeclaredFields();//获取所有的私有字段
        for(Field field:fields){//遍历所有私有字段的名字
            field.setAccessible(true);//访问私有属性
            //获取所有私有字段的名字
            String key = field.getName();//获取类中的属性名
            Object value =map.get(key);//获取map中key与属性名相对应的值
            field.set(instance,value);//
        }
        return (T)instance;



    }

    public static void main(String[] args) throws  Exception {
        Map<String,Object> map =new HashMap<>();
        map.put("name","jack");
        map.put("age",21);
        TestBlackman testBlackman=new TestBlackman();
        Class cls =Class.forName("com.teacher8_17.Mother");
        Object toBean=testBlackman.createTOBean(cls, map);
        System.out.println(toBean.toString());


    }

}
