package com.teacher8_17.computer;


import java.lang.reflect.Method;

public class Reflexcom {
    public static void getfun(Class<?> cls,String name) throws Exception{

        Method method=cls.getDeclaredMethod(name,int.class,int.class);
        Object result=method.invoke(cls.newInstance(),100,100);
        System.out.println(result);
    }

    public static void main(String[] args)throws Exception {
        Class cls=Class.forName("com.teacher8_17.computer.Computer");
        getfun(cls,"sum");
    }
}
