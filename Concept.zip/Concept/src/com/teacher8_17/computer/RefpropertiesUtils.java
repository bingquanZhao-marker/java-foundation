package com.teacher8_17.computer;

import com.teacher8_17.Mother;

import java.io.*;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Properties;
import java.util.UUID;

public class RefpropertiesUtils {
    //传入任意的类，想mother中添加元素
    public static void demo1(Object object) throws Exception {
        Class cls = object.getClass();
        Field[] fields = cls.getDeclaredFields();
        for (Field field : fields) {
            if (field.getGenericType().toString().equals("int")) {
                Method m = object.getClass().getMethod("get" + getMethodName(field.getName()));
                Integer val = (Integer) m.invoke(object);//调用getter方法获取属性值
                System.out.println("----->>" + val);
                if (val != null) {
                    System.out.println("String tppe" + val);
                }

            }
        }

    }

    public static void saveInformationToProperties(String outPath, Object object, String comment) {
        Properties properties = new Properties();
        FileOutputStream outputStream = null;
        File file = new File(outPath);
        if (!file.exists()) {
            file.mkdirs();
        }
        try {
            outputStream = new FileOutputStream(file.getAbsolutePath() + File.separator + UUID.randomUUID()
                    .toString().replaceAll("-", "").substring(1, 20) + ".properties");
            Class<?> cls = object.getClass();//取得object的类型
            Field[] fields = cls.getDeclaredFields();
            for (Field field : fields) {
                if (field.getGenericType().getTypeName().equals("int")) {
                    Method method = cls.getMethod("get" + getMethodName(field.getName()));
                    Integer val = (Integer) method.invoke(object);
                    System.out.println("------>" + val);
                    if (val != null) {
                        properties.setProperty(field.getName(), String.valueOf(val));
                    } else if (field.getGenericType().getTypeName().equals("String")) {
                        System.out.println("结束");
                    }
                    properties.store(outputStream, comment);
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static <T> T getInformationFromProperties(String filePath, Object object) throws Exception {
        File file = new File(filePath);
        Object instance = null;
        if (file.exists()) {
            FileInputStream inputStream = new FileInputStream(file.getAbsolutePath());
            Properties properties = new Properties();
            Class<?> cls=object.getClass();
            if (inputStream != null) {
                properties.load(inputStream);
                instance = cls.newInstance();
                Field[] fields = cls.getDeclaredFields();
                for (Field field : fields) {
                    field.setAccessible(true);
                    String key = field.getName();
                    System.out.println("---->" + key);
                    String value = properties.getProperty(key);
                    System.out.println("----->" + value);
                    field.set(inputStream, value);
                }
            }
            inputStream.close();
        }
        return (T) instance;


    }


    private static String getMethodName(String fieldName) throws Exception {
        byte[] items = fieldName.getBytes();
        items[0] = (byte) ((char) items[0] - 'a' + 'A');
        return new String(items);
    }

    public static void main(String[] args) throws Exception {
        //Mother mother =new Mother();
        // mother.setAge(12);
        //RefpropertiesUtils.demo1(mother);
        //mother.setAge(32);
        //RefpropertiesUtils.saveInformationToProperties
        // ("/Users/apple/desktop/newfile/saveMessage",mother,"this is a annotation");

        RefpropertiesUtils.getInformationFromProperties("/Users/apple/Desktop/newfile/saveMessage/fc994b1259743dcb581.properties", Mother.class);
    }
}
