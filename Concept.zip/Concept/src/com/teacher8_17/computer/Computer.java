package com.teacher8_17.computer;

public class Computer {

    public Computer() {
    }

    public int sum(int a, int b){
        return a+b;
    }

}
